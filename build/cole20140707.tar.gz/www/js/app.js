(function(/*! Brunch !*/) {
  'use strict';

  var globals = typeof window !== 'undefined' ? window : global;
  if (typeof globals.require === 'function') return;

  var modules = {};
  var cache = {};

  var has = function(object, name) {
    return ({}).hasOwnProperty.call(object, name);
  };

  var expand = function(root, name) {
    var results = [], parts, part;
    if (/^\.\.?(\/|$)/.test(name)) {
      parts = [root, name].join('/').split('/');
    } else {
      parts = name.split('/');
    }
    for (var i = 0, length = parts.length; i < length; i++) {
      part = parts[i];
      if (part === '..') {
        results.pop();
      } else if (part !== '.' && part !== '') {
        results.push(part);
      }
    }
    return results.join('/');
  };

  var dirname = function(path) {
    return path.split('/').slice(0, -1).join('/');
  };

  var localRequire = function(path) {
    return function(name) {
      var dir = dirname(path);
      var absolute = expand(dir, name);
      return globals.require(absolute, path);
    };
  };

  var initModule = function(name, definition) {
    var module = {id: name, exports: {}};
    cache[name] = module;
    definition(module.exports, localRequire(name), module);
    return module.exports;
  };

  var require = function(name, loaderPath) {
    var path = expand(name, '.');
    if (loaderPath == null) loaderPath = '/';

    if (has(cache, path)) return cache[path].exports;
    if (has(modules, path)) return initModule(path, modules[path]);

    var dirIndex = expand(path, './index');
    if (has(cache, dirIndex)) return cache[dirIndex].exports;
    if (has(modules, dirIndex)) return initModule(dirIndex, modules[dirIndex]);

    throw new Error('Cannot find module "' + name + '" from '+ '"' + loaderPath + '"');
  };

  var define = function(bundle, fn) {
    if (typeof bundle === 'object') {
      for (var key in bundle) {
        if (has(bundle, key)) {
          modules[key] = bundle[key];
        }
      }
    } else {
      modules[bundle] = fn;
    }
  };

  var list = function() {
    var result = [];
    for (var item in modules) {
      if (has(modules, item)) {
        result.push(item);
      }
    }
    return result;
  };

  globals.require = require;
  globals.require.define = define;
  globals.require.register = define;
  globals.require.list = list;
  globals.require.brunch = true;
})();
require.register("application", function(exports, require, module) {
var Application, BrowseView, ChoicesSingleton, CollectionFormView, CollectionListView, DeleteBrowseView, JobCollection, JobElementFormView, JobListView, JobModel, JobView, PageView, app, _ref,
  __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  __indexOf = [].indexOf || function(item) { for (var i = 0, l = this.length; i < l; i++) { if (i in this && this[i] === item) return i; } return -1; };

ChoicesSingleton = require("models/choices");

JobModel = require("models/job");

JobCollection = require("models/job-collection");

PageView = require("views/page");

CollectionFormView = require("views/collection-form");

CollectionListView = require("views/collection-list");

JobElementFormView = require("views/job-element-form");

JobListView = require("views/job-list");

JobView = require("views/job");

BrowseView = require('views/browse');

DeleteBrowseView = require('views/delete-browse');

module.exports = Application = (function(_super) {
  __extends(Application, _super);

  function Application() {
    this._validateComponent = __bind(this._validateComponent, this);
    this._addComponent = __bind(this._addComponent, this);
    this._saveJob = __bind(this._saveJob, this);
    this._resetJob = __bind(this._resetJob, this);
    this._updateJobName = __bind(this._updateJobName, this);
    this._updateCost = __bind(this._updateCost, this);
    this._viewJob = __bind(this._viewJob, this);
    this._readJob = __bind(this._readJob, this);
    this._createJob = __bind(this._createJob, this);
    this._navigate = __bind(this._navigate, this);
    _ref = Application.__super__.constructor.apply(this, arguments);
    return _ref;
  }

  Application.prototype._jobs = null;

  Application.prototype._current = null;

  Application.prototype._pages = null;

  Application.prototype._steps = {
    home: {
      prev: "home"
    },
    create: {
      next: "add.concrete"
    },
    concrete: {
      prev: "add.create",
      next: "add.labor"
    },
    labor: {
      prev: "add.concrete",
      next: "add.materials"
    },
    materials: {
      prev: "add.labor",
      next: "add.equipment"
    },
    equipment: {
      prev: "add.materials",
      next: "add.subcontractor"
    },
    subcontractor: {
      prev: "add.equipment",
      next: "add.save"
    },
    save: {
      prev: "add.subcontractor"
    }
  };

  Application.prototype.routes = {
    "": "home",
    "home": "home",
    "open": "open",
    "browse": "browse",
    "delete-browse": "deleteBrowse",
    "read.:id": "read",
    "add(.:routeType)": "add",
    "edit(.:routeType)": "edit",
    "delete-job.:id": "deleteJob",
    "delete-group.:group_id": "deleteGroup"
  };

  Application.prototype.initialize = function(opts) {
    console.log("Initializing Cole");
    this._jobs = new JobCollection(null, {
      model: JobModel,
      modelType: "job",
      url: "jobs"
    });
    this._jobs.fetch();
    this._createJob();
    this._bindEvents();
    return this;
  };

  Application.prototype.home = function() {
    console.log("Loading home page");
    this._createJob();
    this._pages = {};
    if (this._pages["home"] == null) {
      this._pages["home"] = new PageView({
        id: "home",
        title: "Cole",
        text: {
          id: "start",
          content: ""
        }
      });
      this._setPage(this._pages["home"]);
    }
    return this._showPage(this._pages["home"]);
  };

  Application.prototype.browse = function() {
    console.log("Loading browse page");
    if (this._pages["browse"] == null) {
      this._pages["browse"] = new PageView({
        id: "browse",
        title: "Load an Estimate",
        subView: new BrowseView({
          routeType: 'browse'
        })
      });
      this._setPage(this._pages["browse"]);
    }
    return this._showPage(this._pages["browse"]);
  };

  Application.prototype.deleteBrowse = function() {
    console.log("Loading delete-browse page");
    if (this._pages["delete-browse"] == null) {
      this._pages["delete-browse"] = new PageView({
        id: "delete-browse",
        title: "Delete an Estimate",
        subView: new DeleteBrowseView({
          routeType: 'delete-browse'
        })
      });
      this._setPage(this._pages["delete-browse"]);
    }
    return this._showPage(this._pages["delete-browse"]);
  };

  Application.prototype.read = function(id) {
    var routeType;
    console.log("Loading job listing page");
    routeType = "read-" + id;
    if (this._pages[routeType] == null) {
      this._readJob(id);
      this._pages[routeType] = new PageView({
        title: this._current.attributes.job_name,
        subView: new JobView({
          model: this._current,
          routeType: 'read'
        })
      });
      this._setPage(this._pages[routeType]);
    }
    return this._showPage(this._pages[routeType]);
  };

  Application.prototype.add = function(routeType) {
    if (routeType == null) {
      routeType = "create";
    }
    console.log("Loading " + routeType + " component page");
    return this._viewJob(routeType);
  };

  Application.prototype.edit = function(routeType) {
    if (routeType == null) {
      routeType = 'create';
    }
    console.log("Editing " + routeType + " component page");
    return this._viewJob(routeType, 'edit');
  };

  Application.prototype.deleteJob = function(id, navigate_home) {
    if (navigate_home == null) {
      navigate_home = true;
    }
    console.log('Deleting job');
    this._readJob(id);
    ChoicesSingleton.removeJobGroup(this._current);
    ChoicesSingleton.save();
    return this._resetJob(navigate_home);
  };

  Application.prototype.deleteGroup = function(group_id) {
    var group_models, id, ids, _i, _len;
    console.log('Deleting group');
    group_models = this._jobs.byGroupId(group_id);
    ids = _.pluck(group_models, 'id');
    for (_i = 0, _len = ids.length; _i < _len; _i++) {
      id = ids[_i];
      this.deleteJob(id, false);
    }
    return this._navigate('home');
  };

  Application.prototype._setPage = function(page) {
    $("body").append(page.render().$el);
    return true;
  };

  Application.prototype._showPage = function(page) {
    $("section").hide();
    page.$el.show();
    return true;
  };

  Application.prototype._bindEvents = function() {
    console.log("Binding events");
    $(document).hammer().on("tap", "button.job.save", this._saveJob);
    $(document).on("tap", "button.ccma-navigate", this._navigateEvent);
    $(document).on("tap", "button.ccma-navigate", this._updateJobName);
    $(document).on("tap", "button.ccma-navigate", this._updateCost);
    $(document).hammer().on("tap", "button.add", this._validateComponent);
    $(document).hammer().on("tap", "button.job.reset", this._resetJob);
    $(document).on("change", ".field", this._updateCost);
    return true;
  };

  Application.prototype._navigateEvent = function(evt) {
    var path, pathNav;
    evt.preventDefault();
    path = $(evt.currentTarget).data("path");
    Backbone.history.navigate(path, true);
    $("nav button").removeClass("active");
    pathNav = path.split(".", 1);
    return $("nav button." + pathNav).addClass("active");
  };

  Application.prototype._navigate = function(path) {
    var pathNav;
    Backbone.history.navigate(path, true);
    $("nav button").removeClass("active");
    pathNav = path.split(".", 1);
    return $("nav button." + pathNav).addClass("active");
  };

  Application.prototype._createJob = function() {
    console.log("Creating new job");
    this._current = new JobModel;
    return this._current;
  };

  Application.prototype._readJob = function(id) {
    console.log("Reading job " + id);
    this._current = this._jobs.get(id);
    return this._current;
  };

  Application.prototype._viewJob = function(routeType, viewType) {
    var collection, view;
    if (routeType == null) {
      routeType = "create";
    }
    if (viewType == null) {
      viewType = "add";
    }
    console.log("Viewing job");
    if (this._pages[routeType] == null) {
      view = null;
      collection = null;
      if (__indexOf.call(ChoicesSingleton.get('job_routes'), routeType) >= 0) {
        collection = this._current.get(routeType);
      }
      if (collection != null) {
        console.log("Creating " + routeType + " collection form view");
        view = new CollectionFormView({
          title: routeType,
          routeType: routeType,
          collection: collection,
          step: this._steps[routeType]
        });
      } else {
        console.log("Creating job element form view");
        if (routeType === 'create' || routeType === 'save') {
          view = new JobElementFormView({
            title: routeType,
            routeType: routeType,
            model: this._current,
            step: this._steps[routeType]
          });
        }
      }
      this._pages[routeType] = new PageView({
        id: routeType,
        title: "Job Builder",
        subView: view
      });
      if (viewType === 'add') {
        this._addComponent(routeType);
      }
      this._setPage(this._pages[routeType]);
    }
    return this._showPage(this._pages[routeType]);
  };

  Application.prototype._updateCost = function() {
    var cost;
    console.log("Recalculating job cost");
    if (this._current != null) {
      cost = this._current.calculate();
    }
    $('.subtotal').text(cost.toFixed(2));
    return this._current;
  };

  Application.prototype._updateJobName = function(currentRoute) {
    var allowedRoutes, headerJobName, routeType;
    if (currentRoute == null) {
      currentRoute = null;
    }
    console.log("Refreshing job name");
    if (typeof currentRoute !== 'string') {
      currentRoute = null;
    }
    currentRoute = currentRoute || Backbone.history.fragment;
    if (currentRoute == null) {
      return;
    }
    allowedRoutes = ["add.concrete", "add.labor", "add.materials", "add.equipment", "add.subcontractor", "add.save", "edit.concrete", "edit.labor", "edit.materials", "edit.equipment", "edit.subcontractor"];
    headerJobName = $('div.header-job-name');
    if (currentRoute.slice(0, 4) === 'read' || __indexOf.call(allowedRoutes, currentRoute) >= 0) {
      headerJobName.find('h3').text(this._current.attributes.job_name);
      headerJobName.show();
      routeType = currentRoute.split('.');
      routeType = routeType[routeType.length - 1];
      if (__indexOf.call(ChoicesSingleton.get('job_routes'), routeType) >= 0) {
        $('div.header-title').find('h3').text(routeType);
      }
    } else {
      headerJobName.hide();
    }
    return this._current;
  };

  Application.prototype._resetJob = function() {
    console.log("Reseting job");
    this._current.destroy();
    this._navigate('home');
    return true;
  };

  Application.prototype._saveJob = function(evt) {
    console.log("Saving job");
    if (this._current.isValid()) {
      this._current.save();
      ChoicesSingleton.addJobGroup(this._current);
      ChoicesSingleton.save();
      this._jobs.add(this._current);
      console.log(JSON.stringify(this._current.toJSON()));
      return true;
    } else {
      alert(this._current.validationError);
      return false;
    }
  };

  Application.prototype._addComponent = function(routeType) {
    if (__indexOf.call(ChoicesSingleton.get('job_routes'), routeType) >= 0) {
      this._current.get(routeType).add({});
    }
    $('select').select2({
      allowClear: true,
      minimumResultsForSearch: 6
    });
    $("input[type=number]").keyup(function() {
      var new_val, template, val;
      val = $(this).val();
      if (val.lastIndexOf('.', 0) === 0) {
        template = '.0000000000';
        if (val === template.substring(0, val.length)) {
          return;
        }
        new_val = '0' + val;
        return $(this).val(new_val);
      }
    });
    return true;
  };

  Application.prototype._validateComponent = function(evt) {
    var last, routeType;
    evt.preventDefault();
    routeType = $(evt.currentTarget).data('type');
    console.log("Validating " + routeType);
    last = this._current.get(routeType).last();
    if (last.isValid()) {
      console.log("Adding " + routeType + " to active job");
      this._addComponent(routeType);
    } else {
      alert(last.validationError);
    }
    return last;
  };

  return Application;

})(Backbone.Router);

module.exports = app = new Application;
});

;require.register("devel", function(exports, require, module) {
var application;

application = require("application");

$(function() {
  return Backbone.history.start();
});
});

;require.register("init", function(exports, require, module) {
var CordovaApp, app, application, cordovaClass;

application = require("application");

cordovaClass = CordovaApp = (function() {
  function CordovaApp() {}

  CordovaApp.prototype.initialize = function() {
    this.bindEvents();
    return true;
  };

  CordovaApp.prototype.bindEvents = function() {
    document.addEventListener('deviceready', this.onDeviceReady, false);
    return true;
  };

  CordovaApp.prototype.onDeviceReady = function() {
    Backbone.history.start();
    return app.receivedEvent('deviceready');
  };

  CordovaApp.prototype.receivedEvent = function(id) {
    var listeningElement, parentElement, receivedElement;
    parentElement = document.getElementById(id);
    listeningElement = parentElement.querySelector('.listening');
    receivedElement = parentElement.querySelector('.received');
    listeningElement.setAttribute('style', 'display:none;');
    receivedElement.setAttribute('style', 'display:block;');
    console.log('Received Event: ' + id);
    return true;
  };

  return CordovaApp;

})();

app = new cordovaClass;

app.initialize();
});

;require.register("models/base", function(exports, require, module) {
var BaseModel, ChoicesSingleton, _ref,
  __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

ChoicesSingleton = require("models/choices");

module.exports = BaseModel = (function(_super) {
  __extends(BaseModel, _super);

  function BaseModel() {
    this.getValue = __bind(this.getValue, this);
    _ref = BaseModel.__super__.constructor.apply(this, arguments);
    return _ref;
  }

  BaseModel.prototype.defaults = {
    "help": null
  };

  BaseModel.prototype.fields = [];

  BaseModel.prototype.cost = 0;

  BaseModel.prototype.check = {
    number: function(value, label, required) {
      var result;
      result = false;
      label = "\"" + label + "\"";
      if (required) {
        if (value == null) {
          result = "You must enter a " + label;
        }
        if (value === "") {
          result = "You must enter a " + label;
        }
      }
      if (value != null) {
        if (isNaN(value)) {
          result = "" + label + " must be a number";
        }
        if (isNaN(parseInt(value))) {
          result = "" + label + " must be a number";
        }
        if (value < 0) {
          result = "" + label + " must be at least 0";
        }
      }
      return result;
    },
    text: function(value, label, required) {
      var result;
      result = false;
      if (required) {
        if (value == null) {
          result = "You must enter a " + label;
        }
        if (value === "") {
          result = "You must enter a " + label;
        }
      }
      return result;
    },
    select: function(value, label, required) {
      var result;
      result = false;
      if (required) {
        if (value == null) {
          result = "You must select a " + label;
        }
        if (value === "") {
          result = "You must select a " + label;
        }
      }
      if (value != null) {
        if (value < 0) {
          result = "You must select a " + label;
        }
      }
      return result;
    }
  };

  BaseModel.prototype.initialize = function() {
    var _this = this;
    return _(this.fields).each(function(field) {
      var _ref1;
      field.displayLabel = (_ref1 = field.label) != null ? _ref1 : field.placeholder;
      return field.options = ChoicesSingleton.get(field.optionsType);
    });
  };

  BaseModel.prototype.validate = function(attrs, opts) {
    var fail, field, label, required, _fn, _i, _len, _ref1, _ref2, _ref3,
      _this = this;
    fail = false;
    _ref1 = this.fields;
    _fn = function(field) {
      if (!fail) {
        fail = (function() {
          switch (field.fieldType) {
            case "number":
            case "text":
            case "select":
              return this.check[field.fieldType](attrs[field.name], label, required);
            default:
              return false;
          }
        }).call(_this);
      }
      return null;
    };
    for (_i = 0, _len = _ref1.length; _i < _len; _i++) {
      field = _ref1[_i];
      required = (_ref2 = field.required) != null ? _ref2 : true;
      label = (_ref3 = field.label) != null ? _ref3 : field.placeholder;
      _fn(field);
    }
    if (!fail) {
      fail = "";
    }
    return fail;
  };

  BaseModel.prototype.getField = function(name) {
    var found, _ref1;
    found = _.where(this.fields, {
      name: name
    });
    return (_ref1 = found[0]) != null ? _ref1 : null;
  };

  BaseModel.prototype.getFields = function(showAll) {
    var field, fields, _i, _len;
    if (showAll == null) {
      showAll = false;
    }
    fields = showAll ? this.fields : _.where(this.fields, {
      show: true
    });
    for (_i = 0, _len = fields.length; _i < _len; _i++) {
      field = fields[_i];
      field.value = this.getValue(field);
    }
    return fields;
  };

  BaseModel.prototype.getValue = function(field) {
    var item, value, _i, _len, _ref1;
    value = this.attributes[field.name];
    console.log("Field is " + field.name + " with value of " + value);
    if (field.options != null) {
      _ref1 = field.options;
      for (_i = 0, _len = _ref1.length; _i < _len; _i++) {
        item = _ref1[_i];
        value = this._setValue(item, value);
      }
    }
    return value;
  };

  BaseModel.prototype._setValue = function(item, value) {
    value = parseInt(item.id) === parseInt(value) ? item.text : value;
    return value;
  };

  return BaseModel;

})(Backbone.Model);
});

;require.register("models/choices", function(exports, require, module) {
var ChoicesModel, choices, _ref,
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

ChoicesModel = (function(_super) {
  __extends(ChoicesModel, _super);

  function ChoicesModel() {
    _ref = ChoicesModel.__super__.constructor.apply(this, arguments);
    return _ref;
  }

  ChoicesModel.prototype.localStorage = new Backbone.LocalStorage("cole-choices");

  ChoicesModel.prototype.url = "choices";

  ChoicesModel.prototype.defaults = {
    concrete_type_options: [
      {
        id: "1",
        text: "Sidewalk"
      }, {
        id: "2",
        text: "Foundation"
      }, {
        id: "3",
        text: "Curb"
      }, {
        id: "4",
        text: "Footings"
      }, {
        id: "5",
        text: "Driveway"
      }
    ],
    concrete_type_options_display: {
      singular: {
        '1': 'sidewalk',
        '2': 'foundation',
        '3': 'curb',
        '4': 'footing',
        '5': 'driveway'
      },
      plural: {
        '1': 'sidewalks',
        '2': 'foundations',
        '3': 'curbs',
        '4': 'footings',
        '5': 'driveways'
      }
    },
    equipment_type_options: [
      {
        id: "1",
        text: "Dump Truck"
      }, {
        id: "2",
        text: "Excavator"
      }, {
        id: "3",
        text: "Bobcat"
      }, {
        id: "4",
        text: "Concrete pump"
      }, {
        id: "5",
        text: "Concrete saw"
      }, {
        id: "6",
        text: "Piles"
      }, {
        id: "7",
        text: "Trial"
      }, {
        id: "8",
        text: "Util Truck"
      }, {
        id: "9",
        text: "Trowel machine"
      }
    ],
    equipment_type_options_display: {
      singular: {
        '1': 'dump truck',
        '2': 'excavator',
        '3': 'bobcat',
        '4': 'concrete pump',
        '5': 'concrete saw',
        '6': 'pile',
        '7': 'trial',
        '8': 'util truck',
        '9': 'trowel machine'
      },
      plural: {
        '1': 'dump trucks',
        '2': 'excavators',
        '3': 'bobcats',
        '4': 'concrete pumps',
        '5': 'concrete saws',
        '6': 'piles',
        '7': 'trials',
        '8': 'util trucks',
        '9': 'trowel machines'
      }
    },
    group_name_options: [],
    job_groups: [],
    job_type_options: [
      {
        id: "1",
        text: "Slab"
      }, {
        id: "2",
        text: "GB- H"
      }, {
        id: "3",
        text: "GB - H1A"
      }, {
        id: "4",
        text: "GB - V"
      }, {
        id: "5",
        text: "Piles"
      }, {
        id: "6",
        text: "Truck Well"
      }
    ],
    job_routes: ['concrete', 'labor', 'materials', 'equipment', 'subcontractor'],
    labor_type_options: [
      {
        id: "1",
        text: "Finishers"
      }, {
        id: "2",
        text: "Supervisors"
      }, {
        id: "3",
        text: "Forms crp"
      }, {
        id: "4",
        text: "Laborers"
      }, {
        id: "5",
        text: "Driver"
      }, {
        id: "6",
        text: "Operator"
      }, {
        id: "7",
        text: "Carpenter"
      }, {
        id: "8",
        text: "Ironworker"
      }
    ],
    labor_type_options_display: {
      singular: {
        '1': 'finisher',
        '2': 'supervisor',
        '3': 'forms crp',
        '4': 'laborer',
        '5': 'driver',
        '6': 'operator'
      },
      plural: {
        '1': 'finishers',
        '2': 'supervisors',
        '3': 'forms crp',
        '4': 'laborers',
        '5': 'drivers',
        '6': 'operators'
      }
    },
    material_type_options: [
      {
        id: "1",
        text: "Wire (sheet)"
      }, {
        id: "2",
        text: "Keyway (lf)"
      }, {
        id: "3",
        text: "Stakes (ea.)"
      }, {
        id: "4",
        text: "Cap (lf)"
      }, {
        id: "5",
        text: "Dowells  (ea.)"
      }, {
        id: "6",
        text: "2x8x20  (lf)"
      }, {
        id: "7",
        text: "Misc"
      }
    ],
    material_type_options_display: {
      singular: {
        '1': 'wire',
        '2': 'keyway',
        '3': 'stake',
        '4': 'cap',
        '5': 'dowell',
        '6': 'lf of 2x8x20',
        '7': 'misc'
      },
      plural: {
        '1': 'wire',
        '2': 'keyways',
        '3': 'stakes',
        '4': 'caps',
        '5': 'dowells',
        '6': 'lf of 2x8x20',
        '7': 'misc'
      }
    },
    measurement_options: [
      {
        id: 'in',
        text: 'Inches'
      }, {
        id: 'ft',
        text: 'Feet'
      }, {
        id: 'yd',
        text: 'Yards'
      }, {
        id: 'cm',
        text: 'Centimeters'
      }, {
        id: 'm',
        text: 'Meters'
      }
    ],
    price_options: [
      {
        id: 'in',
        text: 'Per Cubic Inch'
      }, {
        id: 'ft',
        text: 'Per Cubic Foot'
      }, {
        id: 'yd',
        text: 'Per Cubic Yard'
      }, {
        id: 'cm',
        text: 'Per Cubic Centimeter'
      }, {
        id: 'm',
        text: 'Per Cubic Meter'
      }
    ],
    price_options_display: {
      singular: {
        "in": 'cubic inch',
        ft: 'cubic foot',
        yd: 'cubic yard',
        cm: 'cubic centimeter',
        m: 'cubic meter'
      },
      plural: {
        "in": 'cubic inches',
        ft: 'cubic feet',
        yd: 'cubic yards',
        cm: 'cubic centimeters',
        m: 'cubic meters'
      }
    },
    time_options: [
      {
        id: "hour",
        text: "Hours"
      }, {
        id: "day",
        text: "Days"
      }, {
        id: "week",
        text: "Weeks"
      }, {
        id: "month",
        text: "Months"
      }
    ],
    time_options_display: {
      singular: {
        'hour': 'hour',
        'day': 'day',
        'week': 'week',
        'month': 'month'
      },
      plural: {
        'hour': 'hours',
        'day': 'days',
        'week': 'weeks',
        'month': 'months'
      }
    },
    time_per_options: [
      {
        id: "hour",
        text: "Hourly"
      }, {
        id: "day",
        text: "Daily"
      }, {
        id: "week",
        text: "Weekly"
      }, {
        id: "month",
        text: "Monthly"
      }
    ]
  };

  ChoicesModel.prototype.getTextById = function(options_name, id) {
    var item, item_found, options, _i, _len;
    options = this.get(options_name);
    for (_i = 0, _len = options.length; _i < _len; _i++) {
      item = options[_i];
      if (item.id === id) {
        item_found = item;
      }
    }
    if (item_found != null) {
      return item_found.text;
    }
    return null;
  };

  ChoicesModel.prototype.addJobGroup = function(job) {
    var filtered_job_groups, group_option, item, job_found, selected_group, _i, _j, _len, _len1, _ref1, _ref2;
    _ref1 = this.attributes.group_name_options;
    for (_i = 0, _len = _ref1.length; _i < _len; _i++) {
      item = _ref1[_i];
      if (item.id === job.attributes.group_id) {
        group_option = item;
      }
    }
    _ref2 = this.attributes.job_groups;
    for (_j = 0, _len1 = _ref2.length; _j < _len1; _j++) {
      item = _ref2[_j];
      if (item.group.id === job.attributes.group_id) {
        filtered_job_groups = item;
      }
    }
    job_found = false;
    if (filtered_job_groups != null) {
      selected_group = filtered_job_groups;
      job_found = _.some(selected_group.jobs, function(item_job) {
        return item_job.id === job.id;
      });
    } else {
      selected_group = {
        group: {
          id: group_option.id,
          name: group_option.text
        }
      };
    }
    if (!job_found) {
      if (selected_group.jobs == null) {
        selected_group.jobs = [];
      }
      selected_group.jobs.push({
        id: job.id,
        name: job.attributes.job_name
      });
    }
    if (filtered_job_groups == null) {
      this.attributes.job_groups.push(selected_group);
    }
    return null;
  };

  ChoicesModel.prototype.removeJobGroup = function(job) {
    var filtered_jobs, item, new_item, new_job_groups, _i, _len, _ref1;
    new_job_groups = [];
    _ref1 = this.attributes.job_groups;
    for (_i = 0, _len = _ref1.length; _i < _len; _i++) {
      item = _ref1[_i];
      filtered_jobs = item.jobs.filter(function(job_item) {
        return job_item.id !== job.id;
      });
      if (filtered_jobs.length === 0) {
        this.attributes.group_name_options = _(this.attributes.group_name_options).reject(function(group_item) {
          return group_item.id === job.attributes.group_id;
        });
      } else {
        new_item = {
          group: item.group,
          jobs: filtered_jobs
        };
        new_job_groups.push(new_item);
      }
    }
    this.attributes.job_groups = new_job_groups;
    return null;
  };

  return ChoicesModel;

})(Backbone.Model);

choices = new ChoicesModel({
  id: 1
});

choices.fetch();

module.exports = choices;
});

;require.register("models/concrete", function(exports, require, module) {
var BaseModel, ChoicesSingleton, ConcreteModel, _ref,
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

BaseModel = require("models/base");

ChoicesSingleton = require("models/choices");

module.exports = ConcreteModel = (function(_super) {
  __extends(ConcreteModel, _super);

  function ConcreteModel() {
    _ref = ConcreteModel.__super__.constructor.apply(this, arguments);
    return _ref;
  }

  ConcreteModel.prototype.defaults = {
    "concrete_type": null,
    "quantity": null,
    "depth": null,
    "depth_units": null,
    "width": null,
    "width_units": null,
    "length": null,
    "length_units": null,
    "price": null,
    "price_units": null,
    "tax": null
  };

  ConcreteModel.prototype.volume = 0;

  ConcreteModel.prototype.fields = [
    {
      fieldType: "hidden",
      label: "What item",
      name: "concrete_type",
      show: true,
      optionsType: 'concrete_type_options',
      append: '<hr />'
    }, {
      fieldType: "number",
      name: "quantity",
      label: 'How many',
      show: true
    }, {
      fieldType: "number",
      name: "length",
      label: "How long",
      show: true,
      displayBegin: true,
      hasSiblingField: true
    }, {
      fieldType: "select",
      placeholder: "Unit",
      name: "length_units",
      show: true,
      fieldTypeSelect: true,
      optionsType: 'measurement_options',
      displayEnd: true
    }, {
      fieldType: "number",
      label: "How wide",
      name: "width",
      show: true,
      displayBegin: true,
      hasSiblingField: true
    }, {
      fieldType: "select",
      placeholder: "Unit",
      name: "width_units",
      show: true,
      fieldTypeSelect: true,
      optionsType: 'measurement_options',
      displayEnd: true
    }, {
      fieldType: "number",
      label: "How deep",
      name: "depth",
      show: true,
      displayBegin: true,
      hasSiblingField: true
    }, {
      fieldType: "select",
      placeholder: "Unit",
      name: "depth_units",
      show: true,
      fieldTypeSelect: true,
      optionsType: 'measurement_options',
      displayEnd: true
    }, {
      fieldType: "number",
      label: "What price",
      name: "price",
      show: true,
      displayBegin: true,
      displayPrepend: '$',
      hasSiblingField: true
    }, {
      fieldType: "select",
      placeholder: "Unit",
      name: "price_units",
      show: true,
      fieldTypeSelect: true,
      optionsType: 'price_options',
      displayEnd: true
    }, {
      fieldType: "number",
      label: "What tax rate",
      name: "tax",
      show: true,
      displayAppend: '%',
      inputGroup: true,
      inputGroupAppend: true,
      inputGroupValue: '%'
    }
  ];

  ConcreteModel.prototype.initialize = function() {
    this.help = "Describe each concrete structure to be built";
    return ConcreteModel.__super__.initialize.apply(this, arguments);
  };

  ConcreteModel.prototype.calculate = function() {
    var concrete_type, depth, depth_units, depth_value, length, length_units, length_value, price_units, price_value, quantity, tax, tax_value, width, width_units, width_value, _ref1, _ref10, _ref11, _ref2, _ref3, _ref4, _ref5, _ref6, _ref7, _ref8, _ref9;
    concrete_type = (_ref1 = this.attributes.concrete_type) != null ? _ref1 : '';
    tax = (_ref2 = this.attributes.tax) != null ? _ref2 : 0;
    tax_value = tax / 100;
    price_units = (_ref3 = this.attributes.price_units) != null ? _ref3 : 'ft';
    price_value = (_ref4 = this.attributes.price) != null ? _ref4 : 0;
    depth_units = (_ref5 = this.attributes.depth_units) != null ? _ref5 : 'ft';
    depth_value = (_ref6 = this.attributes.depth) != null ? _ref6 : 0;
    depth = Qty(depth_value + ' ' + depth_units).to(price_units);
    length_units = (_ref7 = this.attributes.length_units) != null ? _ref7 : 'ft';
    length_value = (_ref8 = this.attributes.length) != null ? _ref8 : 0;
    length = Qty(length_value + ' ' + length_units).to(price_units);
    width_units = (_ref9 = this.attributes.width_units) != null ? _ref9 : 'ft';
    width_value = (_ref10 = this.attributes.width) != null ? _ref10 : 0;
    width = Qty(width_value + ' ' + width_units).to(price_units);
    quantity = (_ref11 = this.attributes.quantity) != null ? _ref11 : 0;
    this.volume = depth.mul(length).mul(width).scalar;
    this.volume = this.volume * quantity;
    this.cost = this.volume * price_value;
    this.cost = this.cost + (this.cost * tax_value);
    console.log("concrete row (" + concrete_type + ") #" + this.cid + ": " + depth + " (d) * " + width + " (w) x " + length + " (h) x " + quantity + " @ $" + price_value + " + " + tax + " tax = " + this.cost);
    return this.cost;
  };

  ConcreteModel.prototype.overview = function() {
    var concrete_item, concrete_type, concrete_type_display, concrete_type_key, no_concrete, noun_type, price_item, price_options_display, price_units, price_units_key, price_value, quantity, total_item, volume_item, volume_rounded, _ref1, _ref2, _ref3, _ref4;
    no_concrete = ['No concrete'];
    price_options_display = ChoicesSingleton.get('price_options_display');
    concrete_type_display = ChoicesSingleton.get('concrete_type_options_display');
    price_units_key = (_ref1 = this.attributes.price_units) != null ? _ref1 : 'ft';
    concrete_type_key = (_ref2 = this.attributes.concrete_type) != null ? _ref2 : '1';
    quantity = (_ref3 = this.attributes.quantity) != null ? _ref3 : 0;
    price_value = (_ref4 = parseFloat(this.attributes.price)) != null ? _ref4 : 0;
    if (isNaN(this.volume) || this.volume === 0) {
      return no_concrete;
    } else if (isNaN(price_value) || price_value === 0) {
      return no_concrete;
    }
    noun_type = 'singular';
    if (this.volume > 1) {
      noun_type = 'plural';
    }
    price_units = price_options_display[noun_type][price_units_key];
    noun_type = 'singular';
    if (quantity > 1) {
      noun_type = 'plural';
    }
    concrete_type = concrete_type_display[noun_type][concrete_type_key];
    if (concrete_type == null) {
      concrete_type = ChoicesSingleton.getTextById('concrete_type_options', concrete_type_key).toLowerCase();
    }
    concrete_item = "Items: " + quantity + " " + concrete_type;
    volume_rounded = Math.round(this.volume * 100) / 100;
    volume_item = "" + volume_rounded + " " + price_units + " of concrete";
    price_units = price_options_display.singular[price_units_key];
    price_item = "$" + (price_value.toFixed(2)) + " per " + price_units;
    total_item = "Total price: $" + (this.cost.toFixed(2));
    return [concrete_item, volume_item, price_item, total_item];
  };

  return ConcreteModel;

})(BaseModel);
});

;require.register("models/convert", function(exports, require, module) {
var ConvertModel, _ref,
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

module.exports = ConvertModel = (function(_super) {
  __extends(ConvertModel, _super);

  function ConvertModel() {
    _ref = ConvertModel.__super__.constructor.apply(this, arguments);
    return _ref;
  }

  ConvertModel.prototype.to_hours = function(value, units) {
    var conversion;
    value = value || 0;
    units = units || 'hour';
    if (units === 'hour') {
      conversion = 1;
    } else if (units === 'day') {
      conversion = 8;
    } else if (units === 'week') {
      conversion = 40;
    } else if (units === 'month') {
      conversion = 160;
    }
    return value * conversion;
  };

  ConvertModel.prototype.to_per_hour = function(value, units) {
    var conversion;
    value = value || 0;
    units = units || 'hour';
    if (units === 'hour') {
      conversion = 1;
    } else if (units === 'day') {
      conversion = 8;
    } else if (units === 'week') {
      conversion = 40;
    } else if (units === 'month') {
      conversion = 160;
    }
    return value / conversion;
  };

  return ConvertModel;

})(Backbone.Model);
});

;require.register("models/equipment", function(exports, require, module) {
var BaseModel, ChoicesSingleton, ConvertModel, EquipmentModel, _ref,
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

BaseModel = require("models/base");

ChoicesSingleton = require("models/choices");

ConvertModel = require("models/convert");

module.exports = EquipmentModel = (function(_super) {
  __extends(EquipmentModel, _super);

  function EquipmentModel() {
    _ref = EquipmentModel.__super__.constructor.apply(this, arguments);
    return _ref;
  }

  EquipmentModel.prototype.defaults = {
    "equipment_time": null,
    "equipment_type": null,
    "quantity": null,
    "rate": null,
    "rate_units": null
  };

  EquipmentModel.prototype.fields = [
    {
      fieldType: "hidden",
      label: "Equipment Type",
      name: "equipment_type",
      show: true,
      optionsType: 'equipment_type_options',
      append: '<br />'
    }, {
      fieldType: "number",
      label: "How many",
      name: "quantity",
      show: true
    }, {
      fieldType: "number",
      label: "How long",
      name: "equipment_time",
      show: true
    }, {
      fieldType: "number",
      label: "What rate",
      name: "rate",
      show: true,
      hasSiblingField: true
    }, {
      fieldType: "select",
      placeholder: "Unit",
      name: "rate_units",
      show: true,
      fieldTypeSelect: true,
      optionsType: 'time_per_options'
    }
  ];

  EquipmentModel.prototype.initialize = function() {
    this.help = "List all equipment";
    return EquipmentModel.__super__.initialize.apply(this, arguments);
  };

  EquipmentModel.prototype.calculate = function() {
    var convert, equipment_type, quantity, rate, time, _ref1, _ref2;
    equipment_type = (_ref1 = this.attributes.equipment_type) != null ? _ref1 : '';
    convert = new ConvertModel;
    time = convert.to_hours(this.attributes.equipment_time, this.attributes.rate_units);
    rate = convert.to_per_hour(this.attributes.rate, this.attributes.rate_units);
    quantity = (_ref2 = this.attributes.quantity) != null ? _ref2 : 0;
    this.cost = time * rate * quantity;
    console.log("equipment row (" + equipment_type + ") #" + this.cid + ": " + time + " (" + this.attributes.rate_units + ") x " + quantity + " (quantity) @ $" + rate + " (" + this.attributes.rate_units + ") = " + this.cost);
    return this.cost;
  };

  EquipmentModel.prototype.overview = function() {
    var equipment_item, equipment_time, equipment_time_unit, equipment_type, equipment_type_display, equipment_type_key, no_equipment, noun_type, quantity, rate, rate_key, rate_unit, time_options_display, _ref1, _ref2, _ref3, _ref4, _ref5, _ref6;
    no_equipment = ['No equipment'];
    equipment_type_display = ChoicesSingleton.get('equipment_type_options_display');
    time_options_display = ChoicesSingleton.get('time_options_display');
    equipment_type_key = (_ref1 = this.attributes.equipment_type) != null ? _ref1 : 'dump truck';
    equipment_time = (_ref2 = parseFloat(this.attributes.equipment_time)) != null ? _ref2 : 0;
    rate_key = (_ref3 = this.attributes.rate_units) != null ? _ref3 : 'hour';
    quantity = (_ref4 = parseFloat(this.attributes.quantity)) != null ? _ref4 : 0;
    equipment_time = (_ref5 = parseFloat(this.attributes.equipment_time)) != null ? _ref5 : 0;
    rate = (_ref6 = parseFloat(this.attributes.rate)) != null ? _ref6 : 0;
    if (isNaN(quantity) || quantity === 0) {
      return no_equipment;
    } else if (isNaN(equipment_time) || equipment_time === 0) {
      return no_equipment;
    } else if (isNaN(rate) || rate === 0) {
      return no_equipment;
    }
    quantity = Math.round(quantity * 100) / 100;
    equipment_time = Math.round(equipment_time * 100) / 100;
    noun_type = 'singular';
    if (quantity > 1) {
      noun_type = 'plural';
    }
    equipment_type = equipment_type_display[noun_type][equipment_type_key];
    if (equipment_type == null) {
      equipment_type = ChoicesSingleton.getTextById('equipment_type_options', equipment_type_key).toLowerCase();
    }
    noun_type = 'singular';
    if (equipment_time > 1) {
      noun_type = 'plural';
    }
    equipment_time_unit = time_options_display[noun_type][rate_key];
    rate_unit = time_options_display['singular'][rate_key];
    equipment_item = "" + quantity + " " + equipment_type + " for " + equipment_time + " " + equipment_time_unit + " @ $" + rate + "/" + rate_unit;
    return [equipment_item];
  };

  return EquipmentModel;

})(BaseModel);
});

;require.register("models/job-collection", function(exports, require, module) {
var JobCollection, _ref,
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

module.exports = JobCollection = (function(_super) {
  __extends(JobCollection, _super);

  function JobCollection() {
    _ref = JobCollection.__super__.constructor.apply(this, arguments);
    return _ref;
  }

  JobCollection.prototype.initialize = function(models, opts) {
    this.cost = 0;
    this.modelType = opts.modelType;
    if (opts.url != null) {
      this.url = opts.url;
    }
    this.localStorage = new Backbone.LocalStorage("cole-" + this.modelType);
    return null;
  };

  JobCollection.prototype.calculate = function() {
    var row, _i, _len, _ref1;
    this.cost = 0;
    _ref1 = this.models;
    for (_i = 0, _len = _ref1.length; _i < _len; _i++) {
      row = _ref1[_i];
      this.cost += row.calculate();
    }
    console.log("" + this.modelType + " total", this.cost);
    return this.cost;
  };

  JobCollection.prototype.byGroupId = function(group_id) {
    return this.where({
      group_id: group_id
    });
  };

  return JobCollection;

})(Backbone.Collection);
});

;require.register("models/job", function(exports, require, module) {
var BaseModel, ChoicesSingleton, ConcreteModel, EquipmentModel, JobCollection, JobModel, LaborModel, MaterialModel, SubcontractorModel, _ref,
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

BaseModel = require("models/base");

ConcreteModel = require("models/concrete");

LaborModel = require("models/labor");

MaterialModel = require("models/material");

EquipmentModel = require("models/equipment");

SubcontractorModel = require("models/subcontractor");

JobCollection = require("models/job-collection");

ChoicesSingleton = require("models/choices");

module.exports = JobModel = (function(_super) {
  __extends(JobModel, _super);

  function JobModel() {
    _ref = JobModel.__super__.constructor.apply(this, arguments);
    return _ref;
  }

  JobModel.prototype.localStorage = new Backbone.LocalStorage("cole-job");

  JobModel.prototype.url = "jobs";

  JobModel.prototype.cid = null;

  JobModel.prototype.fields = [
    {
      fieldType: 'hidden',
      name: 'group_id',
      label: 'Group Name',
      optionsType: 'group_name_options',
      show: true,
      append: '<br />'
    }, {
      fieldType: "text",
      name: 'job_name',
      label: 'Job Name',
      show: true
    }, {
      fieldType: "hidden",
      name: "job_type",
      label: "What type of job",
      optionsType: 'job_type_options',
      show: true,
      append: '<br />'
    }, {
      fieldType: "number",
      name: "profit_margin",
      label: "Profit Margin",
      show: false,
      required: false,
      overview: true
    }
  ];

  JobModel.prototype.initialize = function() {
    this.attributes.cid = this.cid;
    return JobModel.__super__.initialize.apply(this, arguments);
  };

  JobModel.prototype.defaults = function() {
    var data;
    data = {
      job_name: null,
      profit_margin: null,
      job_type: null,
      group_id: null
    };
    return this.parse(data);
  };

  JobModel.prototype.parse = function(data) {
    var collection, saved, _i, _len, _ref1;
    _ref1 = ChoicesSingleton.get('job_routes');
    for (_i = 0, _len = _ref1.length; _i < _len; _i++) {
      collection = _ref1[_i];
      saved = data[collection] != null ? data[collection] : false;
      data[collection] = this._inflateCollection(collection, saved);
    }
    return data;
  };

  JobModel.prototype._inflateCollection = function(modelType, data) {
    var model;
    model = (function() {
      switch (modelType) {
        case "concrete":
          return ConcreteModel;
        case "labor":
          return LaborModel;
        case "materials":
          return MaterialModel;
        case "equipment":
          return EquipmentModel;
        case "subcontractor":
          return SubcontractorModel;
      }
    })();
    return new JobCollection(data, {
      model: model,
      modelType: modelType
    });
  };

  JobModel.prototype.calculate = function() {
    this.cost = this.attributes.concrete.calculate() + this.attributes.labor.calculate() + this.attributes.materials.calculate() + this.attributes.equipment.calculate() + this.attributes.subcontractor.calculate();
    if (this.cost) {
      console.log("Job total: " + this.attributes.concrete.cost + " + " + this.attributes.labor.cost + " + " + this.attributes.materials.cost + " + " + this.attributes.equipment.cost + " + " + this.attributes.subcontractor.cost + " = " + this.cost);
    }
    return this.cost;
  };

  return JobModel;

})(BaseModel);
});

;require.register("models/labor", function(exports, require, module) {
var BaseModel, ChoicesSingleton, LaborModel, _ref,
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

BaseModel = require("models/base");

ChoicesSingleton = require("models/choices");

module.exports = LaborModel = (function(_super) {
  __extends(LaborModel, _super);

  function LaborModel() {
    _ref = LaborModel.__super__.constructor.apply(this, arguments);
    return _ref;
  }

  LaborModel.prototype.defaults = {
    "labor_time": null,
    "labor_time_units": null,
    "labor_type": null,
    "laborers_count": null,
    "rate": null,
    "rate_units": null
  };

  LaborModel.prototype.fields = [
    {
      fieldType: "hidden",
      label: "Labor class",
      name: "labor_type",
      show: true,
      optionsType: 'labor_type_options',
      append: '<hr />'
    }, {
      fieldType: "number",
      label: "Number of laborers",
      name: "laborers_count",
      show: true
    }, {
      fieldType: "number",
      label: "Time per laborer",
      name: "labor_time",
      show: true,
      hasSiblingField: true
    }, {
      fieldType: "select",
      placeholder: "Unit",
      name: "labor_time_units",
      show: true,
      fieldTypeSelect: true,
      optionsType: 'time_options'
    }, {
      fieldType: "number",
      label: "Pay Rate",
      name: "rate",
      show: true,
      hasSiblingField: true
    }, {
      fieldType: "select",
      placeholder: "Unit",
      name: "rate_units",
      show: true,
      fieldTypeSelect: true,
      optionsType: 'time_per_options'
    }
  ];

  LaborModel.prototype.initialize = function() {
    return LaborModel.__super__.initialize.apply(this, arguments);
  };

  LaborModel.prototype.calculate = function() {
    var labor_time, labor_time_conversion, labor_time_units, labor_time_value, labor_type, laborers_count, rate, rate_conversion, rate_units, rate_value, _ref1, _ref2, _ref3, _ref4, _ref5, _ref6;
    labor_type = (_ref1 = this.attributes.labor_type) != null ? _ref1 : '';
    labor_time_value = (_ref2 = this.attributes.labor_time) != null ? _ref2 : 0;
    labor_time_units = (_ref3 = this.attributes.labor_time_units) != null ? _ref3 : 'hour';
    if (labor_time_units === 'hour') {
      labor_time_conversion = 1;
    } else if (labor_time_units === 'day') {
      labor_time_conversion = 8;
    } else if (labor_time_units === 'week') {
      labor_time_conversion = 40;
    } else if (labor_time_units === 'month') {
      labor_time_conversion = 160;
    }
    labor_time = labor_time_value * labor_time_conversion;
    rate_value = (_ref4 = this.attributes.rate) != null ? _ref4 : 0;
    rate_units = (_ref5 = this.attributes.rate_units) != null ? _ref5 : 'hour';
    rate = rate_value;
    if (rate_units === 'hour') {
      rate_conversion = 1;
    } else if (rate_units === 'day') {
      rate_conversion = 8;
    } else if (rate_units === 'week') {
      rate_conversion = 40;
    } else if (rate_units === 'month') {
      rate_conversion = 160;
    }
    rate = rate_value / rate_conversion;
    laborers_count = (_ref6 = this.attributes.laborers_count) != null ? _ref6 : 0;
    this.cost = labor_time * rate * laborers_count;
    console.log("labor row (" + labor_type + ") #" + this.cid + ": " + labor_time + " (" + labor_time_units + ") x " + laborers_count + " (laborers_count)  @ $" + rate + " " + labor_time_units + " = " + this.cost);
    return this.cost;
  };

  LaborModel.prototype.overview = function() {
    var labor_time, labor_time_key, labor_time_unit, labor_type, labor_type_display, labor_type_key, laborer_item, laborers_count, no_labor, noun_type, rate, rate_key, rate_unit, time_options_display, _ref1, _ref2, _ref3, _ref4, _ref5, _ref6;
    no_labor = ['No labor'];
    labor_type_display = ChoicesSingleton.get('labor_type_options_display');
    time_options_display = ChoicesSingleton.get('time_options_display');
    labor_type_key = (_ref1 = this.attributes.labor_type) != null ? _ref1 : '1';
    labor_time_key = (_ref2 = this.attributes.labor_time_units) != null ? _ref2 : 'hour';
    rate_key = (_ref3 = this.attributes.rate_units) != null ? _ref3 : 'hour';
    laborers_count = (_ref4 = parseFloat(this.attributes.laborers_count)) != null ? _ref4 : 0;
    labor_time = (_ref5 = parseFloat(this.attributes.labor_time)) != null ? _ref5 : 0;
    rate = (_ref6 = parseFloat(this.attributes.rate)) != null ? _ref6 : 0;
    if (isNaN(laborers_count) || laborers_count === 0) {
      return no_labor;
    } else if (isNaN(labor_time) || labor_time === 0) {
      return no_labor;
    } else if (isNaN(rate) || rate === 0) {
      return no_labor;
    }
    laborers_count = Math.round(laborers_count * 100) / 100;
    labor_time = Math.round(labor_time * 100) / 100;
    rate = Math.round(rate * 100) / 100;
    noun_type = 'singular';
    if (laborers_count > 1) {
      noun_type = 'plural';
    }
    labor_type = labor_type_display[noun_type][labor_type_key];
    if (labor_type == null) {
      labor_type = ChoicesSingleton.getTextById('labor_type_options', labor_type_key).toLowerCase();
    }
    noun_type = 'singular';
    if (labor_time > 1) {
      noun_type = 'plural';
    }
    labor_time_unit = time_options_display[noun_type][labor_time_key];
    rate_unit = time_options_display['singular'][rate_key];
    laborer_item = "" + laborers_count + " " + labor_type + " for " + labor_time + " " + labor_time_unit + " @ $" + rate + "/" + rate_unit;
    return [laborer_item];
  };

  return LaborModel;

})(BaseModel);
});

;require.register("models/material", function(exports, require, module) {
var BaseModel, ChoicesSingleton, MaterialModel, _ref,
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

BaseModel = require("models/base");

ChoicesSingleton = require("models/choices");

module.exports = MaterialModel = (function(_super) {
  __extends(MaterialModel, _super);

  function MaterialModel() {
    _ref = MaterialModel.__super__.constructor.apply(this, arguments);
    return _ref;
  }

  MaterialModel.prototype.defaults = {
    "quantity": null,
    "price": null,
    "material_type": null,
    "tax": null
  };

  MaterialModel.prototype.fields = [
    {
      fieldType: "select",
      name: "material_type",
      label: "Material Type",
      show: true,
      fieldTypeSelect: true,
      optionsType: 'material_type_options'
    }, {
      fieldType: "number",
      name: "quantity",
      label: "How many",
      show: true
    }, {
      fieldType: "number",
      name: "price",
      label: "What price",
      show: true
    }, {
      fieldType: "select",
      name: "material_type",
      label: "What Type",
      show: false
    }, {
      fieldType: "number",
      name: "tax",
      label: "What tax rate",
      show: true,
      displayAppend: '%',
      inputGroup: true,
      inputGroupAppend: true,
      inputGroupValue: '%'
    }
  ];

  MaterialModel.prototype.initialize = function() {
    this.help = "Describe all the material needed on the job";
    return MaterialModel.__super__.initialize.apply(this, arguments);
  };

  MaterialModel.prototype.calculate = function() {
    var material_type, price, quantity, tax, tax_value, _ref1, _ref2, _ref3, _ref4;
    material_type = (_ref1 = this.attributes.material_type) != null ? _ref1 : '';
    tax = (_ref2 = this.attributes.tax) != null ? _ref2 : 0;
    tax_value = tax / 100;
    quantity = (_ref3 = this.attributes.quantity) != null ? _ref3 : 0;
    price = (_ref4 = this.attributes.price) != null ? _ref4 : 0;
    this.cost = quantity * price;
    this.cost = this.cost + (this.cost * tax_value);
    console.log("material row (" + material_type + ") #" + this.cid + ": " + quantity + "@" + price + " + " + tax + " tax = " + this.cost);
    return this.cost;
  };

  MaterialModel.prototype.overview = function() {
    var material_item, material_type, material_type_display, material_type_key, no_material, noun_type, price, price_type, quantity, _ref1, _ref2, _ref3;
    no_material = ['No material'];
    material_type_display = ChoicesSingleton.get('material_type_options_display');
    material_type_key = (_ref1 = this.attributes.material_type) != null ? _ref1 : 'wire';
    quantity = (_ref2 = parseFloat(this.attributes.quantity)) != null ? _ref2 : 0;
    price = (_ref3 = parseFloat(this.attributes.price)) != null ? _ref3 : 0;
    if (isNaN(quantity) || quantity === 0) {
      return no_material;
    }
    if (isNaN(price) || price === 0) {
      return no_material;
    }
    quantity = Math.round(quantity * 100) / 100;
    price = Math.round(price * 100) / 100;
    noun_type = 'singular';
    if (quantity > 1) {
      noun_type = 'plural';
    }
    material_type = material_type_display[noun_type][material_type_key];
    price_type = material_type_display['singular'][material_type_key];
    material_item = "" + quantity + " " + material_type + " @ $" + price + "/" + price_type;
    return [material_item];
  };

  return MaterialModel;

})(BaseModel);
});

;require.register("models/subcontractor", function(exports, require, module) {
var BaseModel, SubcontractorModel, _ref,
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

BaseModel = require("models/base");

module.exports = SubcontractorModel = (function(_super) {
  __extends(SubcontractorModel, _super);

  function SubcontractorModel() {
    _ref = SubcontractorModel.__super__.constructor.apply(this, arguments);
    return _ref;
  }

  SubcontractorModel.prototype.defaults = {
    "scope_of_work": null,
    "contractor_amount": null
  };

  SubcontractorModel.prototype.fields = [
    {
      fieldType: "text",
      name: 'scope_of_work',
      label: 'Scope of Work',
      show: true
    }, {
      fieldType: "number",
      name: "contractor_amount",
      label: 'Contractor Amount',
      show: true
    }
  ];

  SubcontractorModel.prototype.initialize = function() {
    return SubcontractorModel.__super__.initialize.apply(this, arguments);
  };

  SubcontractorModel.prototype.calculate = function() {
    var scope_of_work, _ref1, _ref2;
    scope_of_work = (_ref1 = this.attributes.scope_of_work) != null ? _ref1 : '';
    this.cost = (_ref2 = this.attributes.contractor_amount) != null ? _ref2 : 0;
    this.cost = parseFloat(this.cost);
    console.log("subcontractor row (" + scope_of_work + ") #" + this.cid + ": cost " + this.cost);
    return this.cost;
  };

  SubcontractorModel.prototype.overview = function() {
    var contractor_amount, no_subcontractor, scope_of_work, subcontractor_item, _ref1, _ref2;
    no_subcontractor = ['No subcontractor'];
    scope_of_work = (_ref1 = this.attributes.scope_of_work) != null ? _ref1 : '';
    contractor_amount = (_ref2 = parseFloat(this.attributes.contractor_amount)) != null ? _ref2 : 0;
    if (isNaN(contractor_amount) || contractor_amount === 0) {
      return no_subcontractor;
    }
    subcontractor_item = "" + scope_of_work + ": $" + (contractor_amount.toFixed(2));
    return [subcontractor_item];
  };

  return SubcontractorModel;

})(BaseModel);
});

;require.register("templates/browse", function(exports, require, module) {
var __templateData = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, functionType="function", escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\n            <optgroup label=\"Group: "
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.group)),stack1 == null || stack1 === false ? stack1 : stack1.name)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\">\n                ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.jobs), {hash:{},inverse:self.noop,fn:self.program(2, program2, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n            </optgroup>\n        ";
  return buffer;
  }
function program2(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n                    <option value=\"";
  if (helper = helpers.id) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.id); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\">";
  if (helper = helpers.name) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.name); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</option>\n                ";
  return buffer;
  }

  buffer += "<fieldset class=\"form-group\">\n    <label for=\"browse-jobs\" class=\"lead\">Browse Jobs</label>\n    <select id=\"browse-jobs\" name=\"browse-jobs\" class=\"field type form-control\">\n        <option></option>\n        ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.job_groups), {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n    </select>\n</fieldset>\n\n<br />\n<div class=\"row\">\n    <div class=\"col-xs-6 col-xs-offset-6\">\n        <button id=\"browse-button\" class=\"btn btn-default next ccma-navigate form-control\" data-path=\"\" role=\"button\">Load Estimate</button>\n    </div>\n</div>\n";
  return buffer;
  });
if (typeof define === 'function' && define.amd) {
  define([], function() {
    return __templateData;
  });
} else if (typeof module === 'object' && module && module.exports) {
  module.exports = __templateData;
} else {
  __templateData;
}
});

;require.register("templates/collection.form", function(exports, require, module) {
var __templateData = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, functionType="function", escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n    <hr />\n    <div class=\"row\">\n        <div class=\"col-xs-12\">\n            <button class=\"";
  if (helper = helpers.routeType) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.routeType); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + " add btn btn-default form-control\" data-type=\"";
  if (helper = helpers.routeType) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.routeType); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\">\n                <i class=\"fa fa-plus-circle\"></i>\n                Add another\n            </button>\n        </div>\n    </div>\n";
  return buffer;
  }

function program3(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n        <div class=\"col-xs-6\">\n            <button class=\"";
  if (helper = helpers.routeType) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.routeType); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + " btn btn-large form-control next ccma-navigate\" data-path=\""
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.step)),stack1 == null || stack1 === false ? stack1 : stack1.next)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\">Next</button>\n        </div>\n    ";
  return buffer;
  }

  buffer += "<div id=\"component-help\" class=\"well\"></div>\n\n<div class=\"";
  if (helper = helpers.routeType) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.routeType); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + " items\"></div>\n\n";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.multiple), {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n\n<hr />\n\n<div class=\"container\">\n    <div class=\"row cost-summary\">\n        <div class=\"col-xs-12\">\n            <div class=\"lead\">\n                <span class=\"capitalize\">";
  if (helper = helpers.routeType) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.routeType); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</span> $<span class=\"";
  if (helper = helpers.routeType) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.routeType); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + " cost\">0</span>\n                <br />\n                Subtotal $<span class=\"subtotal\">0</span>\n            </div>\n        </div>\n    </div>\n</div>\n<br />\n\n<div class=\"row\">\n    <div class=\"col-xs-6\">\n        <button class=\"btn btn-primary job save ccma-navigate form-control\" data-path=\"home\" role=\"button\">Save & Exit</button>\n    </div>\n    ";
  stack1 = helpers['if'].call(depth0, ((stack1 = (depth0 && depth0.step)),stack1 == null || stack1 === false ? stack1 : stack1.next), {hash:{},inverse:self.noop,fn:self.program(3, program3, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n</div>\n";
  return buffer;
  });
if (typeof define === 'function' && define.amd) {
  define([], function() {
    return __templateData;
  });
} else if (typeof module === 'object' && module && module.exports) {
  module.exports = __templateData;
} else {
  __templateData;
}
});

;require.register("templates/collection.list", function(exports, require, module) {
var __templateData = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, functionType="function", escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  
  return "\n                    <div class=\"col-xs-2 pull-right\">\n                        <i class=\"fa fa-arrow-down\"></i>\n                    </div>\n                ";
  }

function program3(depth0,data) {
  
  
  return "in";
  }

function program5(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n                    <div class=\"col-xs-6\">\n                        <button class=\"btn btn-primary pull-right btn-overview-edit ccma-navigate\" data-path=\"edit.";
  if (helper = helpers.modelType) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.modelType); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\">\n                            <i class=\"fa fa-edit\"></i> Edit\n                        </button>\n                    </div>\n                ";
  return buffer;
  }

  buffer += "<div class=\"panel panel-overview\">\n    <div class=\"panel-heading\">\n        <a class=\"panel-heading-link\" data-toggle=\"collapse\" data-parent=\"#job-accordion\" href=\"#";
  if (helper = helpers.routeType) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.routeType); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "-";
  if (helper = helpers.modelType) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.modelType); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\">\n            <div class=\"row\">\n                <div class=\"col-xs-10\">\n                    <h4 class=\"panel-title capitalize\">\n                        ";
  if (helper = helpers.title) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.title); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\n                    </h4>\n                </div>\n                ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.title), {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n            </div>\n        </a>\n    </div>\n\n    <div id=\"";
  if (helper = helpers.routeType) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.routeType); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "-";
  if (helper = helpers.modelType) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.modelType); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\" class=\"panel-collapse collapse ";
  stack1 = helpers.unless.call(depth0, (depth0 && depth0.title), {hash:{},inverse:self.noop,fn:self.program(3, program3, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\">\n        <div class=\"panel-body\">\n            <div class=\"row\">\n                <div class=\"col-xs-6 ";
  if (helper = helpers.modelType) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.modelType); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + " text-overview lead\">\n                    Cost: $<span class=\"";
  if (helper = helpers.modelType) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.modelType); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + " cost\">";
  if (helper = helpers.cost) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.cost); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</span>\n                </div>\n                ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.title), {hash:{},inverse:self.noop,fn:self.program(5, program5, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n            </div>\n\n            <ul class=\"";
  if (helper = helpers.modelType) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.modelType); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + " items list-group\"></ul>\n        </div>\n    </div>\n</div>\n";
  return buffer;
  });
if (typeof define === 'function' && define.amd) {
  define([], function() {
    return __templateData;
  });
} else if (typeof module === 'object' && module && module.exports) {
  module.exports = __templateData;
} else {
  __templateData;
}
});

;require.register("templates/component.form", function(exports, require, module) {
var __templateData = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, functionType="function", escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data,depth1) {
  
  var buffer = "", stack1;
  buffer += "\n        ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.show), {hash:{},inverse:self.noop,fn:self.programWithDepth(2, program2, data, depth1),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n    ";
  return buffer;
  }
function program2(depth0,data,depth2) {
  
  var buffer = "", stack1, helper;
  buffer += "\n            <label for=\""
    + escapeExpression(((stack1 = (depth2 && depth2.routeType)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "-";
  if (helper = helpers.name) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.name); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "-"
    + escapeExpression(((stack1 = (depth2 && depth2.cid)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\" class=\"lead\">";
  if (helper = helpers.label) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.label); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</label>\n            ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.fieldTypeSelect), {hash:{},inverse:self.programWithDepth(10, program10, data, depth2),fn:self.programWithDepth(3, program3, data, depth2),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n            ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.append), {hash:{},inverse:self.noop,fn:self.program(16, program16, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n        ";
  return buffer;
  }
function program3(depth0,data,depth3) {
  
  var buffer = "", stack1, helper;
  buffer += "\n                <select id=\""
    + escapeExpression(((stack1 = (depth3 && depth3.routeType)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "-";
  if (helper = helpers.name) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.name); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "-"
    + escapeExpression(((stack1 = (depth3 && depth3.cid)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\"\n                        name=\"";
  if (helper = helpers.name) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.name); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\"\n                        class=\"field ";
  if (helper = helpers.fieldType) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.fieldType); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + " type form-control";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.hasSiblingField), {hash:{},inverse:self.noop,fn:self.program(4, program4, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\"\n                        data-placeholder=\"";
  if (helper = helpers.placeholder) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.placeholder); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\"\n                >\n                    <option></option>\n                    ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.options), {hash:{},inverse:self.noop,fn:self.program(6, program6, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                </select>\n                ";
  stack1 = helpers.unless.call(depth0, (depth0 && depth0.append), {hash:{},inverse:self.noop,fn:self.program(8, program8, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n            ";
  return buffer;
  }
function program4(depth0,data) {
  
  
  return " has-sibling-field";
  }

function program6(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n                        <option value=\"";
  if (helper = helpers.id) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.id); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\">";
  if (helper = helpers.text) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.text); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</option>\n                    ";
  return buffer;
  }

function program8(depth0,data) {
  
  
  return "\n                    <br />\n                ";
  }

function program10(depth0,data,depth3) {
  
  var buffer = "", stack1, helper;
  buffer += "\n                ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.inputGroup), {hash:{},inverse:self.noop,fn:self.program(11, program11, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                <input type=\"";
  if (helper = helpers.fieldType) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.fieldType); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\"\n                       id=\""
    + escapeExpression(((stack1 = (depth3 && depth3.routeType)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "-";
  if (helper = helpers.name) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.name); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "-"
    + escapeExpression(((stack1 = (depth3 && depth3.cid)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\"\n                       name=\"";
  if (helper = helpers.name) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.name); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\"\n                       placeholder=\"";
  if (helper = helpers.placeholder) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.placeholder); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\"\n                       value=\"";
  if (helper = helpers.value) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.value); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\"\n                       class=\"field "
    + escapeExpression(((stack1 = (depth3 && depth3.routeType)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + " ";
  if (helper = helpers.name) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.name); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + " form-control";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.hasSiblingField), {hash:{},inverse:self.noop,fn:self.program(4, program4, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\" />\n                ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.inputGroup), {hash:{},inverse:self.noop,fn:self.program(14, program14, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n            ";
  return buffer;
  }
function program11(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\n                    <div class=\"input-group\">\n                    ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.inputGroupPrepend), {hash:{},inverse:self.noop,fn:self.program(12, program12, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                ";
  return buffer;
  }
function program12(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n                        <span class=\"input-group-addon\">";
  if (helper = helpers.inputGroupValue) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.inputGroupValue); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</span>\n                    ";
  return buffer;
  }

function program14(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\n                    ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.inputGroupAppend), {hash:{},inverse:self.noop,fn:self.program(12, program12, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                    </div>\n                ";
  return buffer;
  }

function program16(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n                ";
  if (helper = helpers.append) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.append); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n            ";
  return buffer;
  }

  buffer += "<fieldset class=\"form-group\">\n    ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.fields), {hash:{},inverse:self.noop,fn:self.programWithDepth(1, program1, data, depth0),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n</fieldset>\n";
  return buffer;
  });
if (typeof define === 'function' && define.amd) {
  define([], function() {
    return __templateData;
  });
} else if (typeof module === 'object' && module && module.exports) {
  module.exports = __templateData;
} else {
  __templateData;
}
});

;require.register("templates/component.list", function(exports, require, module) {
var __templateData = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, functionType="function", escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  var buffer = "";
  buffer += "\n        <div>"
    + escapeExpression((typeof depth0 === functionType ? depth0.apply(depth0) : depth0))
    + "</div>\n    ";
  return buffer;
  }

  buffer += "<div class=\"display\">\n    ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.overview_items), {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n    <span>";
  if (helper = helpers.overview) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.overview); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</span>\n</div>\n";
  return buffer;
  });
if (typeof define === 'function' && define.amd) {
  define([], function() {
    return __templateData;
  });
} else if (typeof module === 'object' && module && module.exports) {
  module.exports = __templateData;
} else {
  __templateData;
}
});

;require.register("templates/create.form", function(exports, require, module) {
var __templateData = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, functionType="function", escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data,depth1) {
  
  var buffer = "", stack1;
  buffer += "\n        ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.show), {hash:{},inverse:self.noop,fn:self.programWithDepth(2, program2, data, depth1),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n    ";
  return buffer;
  }
function program2(depth0,data,depth2) {
  
  var buffer = "", stack1, helper;
  buffer += "\n            <label for=\""
    + escapeExpression(((stack1 = (depth2 && depth2.routeType)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "-";
  if (helper = helpers.name) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.name); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "-"
    + escapeExpression(((stack1 = (depth2 && depth2.cid)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\" class=\"lead\">";
  if (helper = helpers.label) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.label); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</label>\n            ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.fieldTypeSelect), {hash:{},inverse:self.programWithDepth(10, program10, data, depth2),fn:self.programWithDepth(3, program3, data, depth2),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n            ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.append), {hash:{},inverse:self.noop,fn:self.program(12, program12, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n        ";
  return buffer;
  }
function program3(depth0,data,depth3) {
  
  var buffer = "", stack1, helper;
  buffer += "\n                <select id=\""
    + escapeExpression(((stack1 = (depth3 && depth3.routeType)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "-";
  if (helper = helpers.name) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.name); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "-"
    + escapeExpression(((stack1 = (depth3 && depth3.cid)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\" name=\"";
  if (helper = helpers.name) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.name); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\" class=\"field ";
  if (helper = helpers.fieldType) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.fieldType); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + " type form-control";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.hasSiblingField), {hash:{},inverse:self.noop,fn:self.program(4, program4, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\" data-placeholder=\"";
  if (helper = helpers.placeholder) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.placeholder); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\">\n                    <option></option>\n                    ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.options), {hash:{},inverse:self.noop,fn:self.program(6, program6, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                </select>\n                ";
  stack1 = helpers.unless.call(depth0, (depth0 && depth0.append), {hash:{},inverse:self.noop,fn:self.program(8, program8, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n            ";
  return buffer;
  }
function program4(depth0,data) {
  
  
  return " has-sibling-field";
  }

function program6(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n                        <option value=\"";
  if (helper = helpers.id) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.id); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\">";
  if (helper = helpers.text) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.text); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</option>\n                    ";
  return buffer;
  }

function program8(depth0,data) {
  
  
  return "\n                    <br />\n                ";
  }

function program10(depth0,data,depth3) {
  
  var buffer = "", stack1, helper;
  buffer += "\n                <input type=\"";
  if (helper = helpers.fieldType) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.fieldType); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\" id=\""
    + escapeExpression(((stack1 = (depth3 && depth3.routeType)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "-";
  if (helper = helpers.name) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.name); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "-"
    + escapeExpression(((stack1 = (depth3 && depth3.cid)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\" name=\"";
  if (helper = helpers.name) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.name); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\" placeholder=\"";
  if (helper = helpers.placeholder) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.placeholder); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\" value=\"";
  if (helper = helpers.value) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.value); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\" class=\"field "
    + escapeExpression(((stack1 = (depth3 && depth3.routeType)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + " ";
  if (helper = helpers.name) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.name); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + " form-control";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.hasSiblingField), {hash:{},inverse:self.noop,fn:self.program(4, program4, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\" />\n            ";
  return buffer;
  }

function program12(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n                ";
  if (helper = helpers.append) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.append); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n            ";
  return buffer;
  }

function program14(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n    <div class=\"row\">\n        <div class=\"col-xs-6 col-xs-offset-6\">\n            <button class=\"";
  if (helper = helpers.type) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.type); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + " btn btn-default next ccma-navigate form-control\" data-path=\""
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.step)),stack1 == null || stack1 === false ? stack1 : stack1.next)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\" role=\"button\">Next</button>\n        </div>\n    </div>\n";
  return buffer;
  }

  buffer += "<fieldset class=\"form-group\">\n    ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.fields), {hash:{},inverse:self.noop,fn:self.programWithDepth(1, program1, data, depth0),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n</fieldset>\n\n";
  stack1 = helpers['if'].call(depth0, ((stack1 = (depth0 && depth0.step)),stack1 == null || stack1 === false ? stack1 : stack1.next), {hash:{},inverse:self.noop,fn:self.program(14, program14, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n";
  return buffer;
  });
if (typeof define === 'function' && define.amd) {
  define([], function() {
    return __templateData;
  });
} else if (typeof module === 'object' && module && module.exports) {
  module.exports = __templateData;
} else {
  __templateData;
}
});

;require.register("templates/delete-browse", function(exports, require, module) {
var __templateData = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, functionType="function", escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\n            <optgroup label=\"Group: "
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.group)),stack1 == null || stack1 === false ? stack1 : stack1.name)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\">\n                ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.jobs), {hash:{},inverse:self.noop,fn:self.program(2, program2, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n            </optgroup>\n        ";
  return buffer;
  }
function program2(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n                    <option value=\"";
  if (helper = helpers.id) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.id); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\">";
  if (helper = helpers.name) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.name); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</option>\n                ";
  return buffer;
  }

function program4(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\n            <option value=\""
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.group)),stack1 == null || stack1 === false ? stack1 : stack1.id)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\">"
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.group)),stack1 == null || stack1 === false ? stack1 : stack1.name)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "</option>\n        ";
  return buffer;
  }

  buffer += "<fieldset class=\"form-group\">\n    <label for=\"delete-job\" class=\"lead ccma-lead\">Browse Jobs</label>\n    <select id=\"delete-job\" name=\"delete-job\" class=\"field type form-control\">\n        <option></option>\n        ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.job_groups), {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n    </select>\n</fieldset>\n\n<br />\n<div class=\"row\">\n    <div class=\"col-xs-6 col-xs-offset-6\">\n        <button id=\"delete-job-button\" class=\"btn btn-default next form-control\" data-path=\"\" data-name=\"\" role=\"button\">Delete Estimate</button>\n    </div>\n</div>\n\n<hr />\n\n<fieldset class=\"form-group\">\n    <label for=\"delete-group\" class=\"lead ccma-lead\">Browse Groups</label>\n    <select id=\"delete-group\" name=\"delete-group\" class=\"field type form-control\">\n        <option></option>\n        ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.job_groups), {hash:{},inverse:self.noop,fn:self.program(4, program4, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n    </select>\n    <div>Deleting a group also deletes all related jobs</div>\n</fieldset>\n<br />\n<div class=\"row\">\n    <div class=\"col-xs-6 col-xs-offset-6\">\n        <button id=\"delete-group-button\" class=\"btn btn-default next form-control\" data-path=\"\" data-name=\"\" role=\"button\">Delete Group</button>\n    </div>\n</div>\n\n";
  return buffer;
  });
if (typeof define === 'function' && define.amd) {
  define([], function() {
    return __templateData;
  });
} else if (typeof module === 'object' && module && module.exports) {
  module.exports = __templateData;
} else {
  __templateData;
}
});

;require.register("templates/header", function(exports, require, module) {
var __templateData = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, functionType="function", escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\n                <div class=\"col-xs-4\">\n                    <button data-path=\""
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.step)),stack1 == null || stack1 === false ? stack1 : stack1.prev)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\" class=\"prev btn btn-nav ccma-navigate navbar-btn\" role=\"button\">\n                        <i class=\"fa fa-arrow-left fa-2x\"></i><br />Back\n                    </button>\n                </div>\n            ";
  return buffer;
  }

function program3(depth0,data) {
  
  
  return " col-xs-offset-4";
  }

function program5(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\n                <div class=\"col-xs-4\">\n                    <button data-path=\""
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.step)),stack1 == null || stack1 === false ? stack1 : stack1.next)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\" class=\"next btn btn-nav ccma-navigate navbar-btn pull-right\" role=\"button\">\n                        <i class=\"fa fa-arrow-right fa-2x\"></i><br />Next\n                    </button>\n                </div>\n            ";
  return buffer;
  }

  buffer += "<nav class=\"navbar navbar-default\" role=\"navigation\">\n    <div class=\"container\">\n        <div class=\"row\">\n            ";
  stack1 = helpers['if'].call(depth0, ((stack1 = (depth0 && depth0.step)),stack1 == null || stack1 === false ? stack1 : stack1.prev), {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n\n            <div class=\"col-xs-4";
  stack1 = helpers.unless.call(depth0, ((stack1 = (depth0 && depth0.step)),stack1 == null || stack1 === false ? stack1 : stack1.prev), {hash:{},inverse:self.noop,fn:self.program(3, program3, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\">\n                <button data-path=\"home\" class=\"home btn btn-nav ccma-navigate navbar-btn center-block\" role=\"button\">\n                    <i class=\"fa fa-home fa-2x\"></i><br />Home\n                </button>\n            </div>\n\n            ";
  stack1 = helpers['if'].call(depth0, ((stack1 = (depth0 && depth0.step)),stack1 == null || stack1 === false ? stack1 : stack1.next), {hash:{},inverse:self.noop,fn:self.program(5, program5, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n        </div>\n    </div>\n</nav>\n\n<div class=\"header-job-name\">\n    <div class=\"container\">\n        <h3></h3>\n    </div>\n</div>\n\n<div class=\"header-title\">\n    <div class=\"container\">\n        <h3>";
  if (helper = helpers.title) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.title); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</h3>\n    </div>\n</div>\n";
  return buffer;
  });
if (typeof define === 'function' && define.amd) {
  define([], function() {
    return __templateData;
  });
} else if (typeof module === 'object' && module && module.exports) {
  module.exports = __templateData;
} else {
  __templateData;
}
});

;require.register("templates/job", function(exports, require, module) {
var __templateData = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, functionType="function", escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\n    ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.overview), {hash:{},inverse:self.noop,fn:self.programWithDepth(2, program2, data, depth0),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n";
  return buffer;
  }
function program2(depth0,data,depth1) {
  
  var buffer = "", stack1, helper;
  buffer += "\n        <div class=\"field "
    + escapeExpression(((stack1 = (depth1 && depth1.routeType)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + " ";
  if (helper = helpers.name) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.name); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + " text-info\"><strong>";
  if (helper = helpers.placeholder) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.placeholder); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</strong>: ";
  if (helper = helpers.value) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.value); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</div>\n    ";
  return buffer;
  }

  buffer += "<h2>"
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.row)),stack1 == null || stack1 === false ? stack1 : stack1.title)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "</h2>\n\n";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.row), {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n\n<div class=\"";
  if (helper = helpers.routeType) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.routeType); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + " text-success\">\n    <strong>Cost: $<span class=\"";
  if (helper = helpers.routeType) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.routeType); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + " cost\">";
  if (helper = helpers.cost) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.cost); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</span></strong>\n</div>\n\n<div class=\"job items panel-group\"></div>\n\n";
  return buffer;
  });
if (typeof define === 'function' && define.amd) {
  define([], function() {
    return __templateData;
  });
} else if (typeof module === 'object' && module && module.exports) {
  module.exports = __templateData;
} else {
  __templateData;
}
});

;require.register("templates/job.list", function(exports, require, module) {
var __templateData = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, functionType="function", escapeExpression=this.escapeExpression;


  buffer += "<a class=\"job list-group-item\" href=\"#read.";
  if (helper = helpers.id) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.id); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\">\n    <h4 class=\"job list-group-item-heading\">"
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.row)),stack1 == null || stack1 === false ? stack1 : stack1.name)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "</h4>\n    <div class=\"job list-group-item-text text-info\">\n        Cost: $<span class=\"job cost\">";
  if (helper = helpers.cost) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.cost); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</span>\n    </div>\n</a>\n";
  return buffer;
  });
if (typeof define === 'function' && define.amd) {
  define([], function() {
    return __templateData;
  });
} else if (typeof module === 'object' && module && module.exports) {
  module.exports = __templateData;
} else {
  __templateData;
}
});

;require.register("templates/page", function(exports, require, module) {
var __templateData = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<div class=\"container\">\n    <div class=\"row\">\n        <div class=\"col-xs-12 lead\">\n            <div>\n                <a href=\"#add\" class=\"create-link\">\n                    Create new estimate\n                </a>\n            </div>\n            <hr />\n\n            <div>\n                <a href=\"#browse\" class=\"create-link\">\n                    Load saved estimate\n                </a>\n            </div>\n            <hr />\n\n            <div>\n                <a href=\"#delete-browse\" class=\"create-link\">\n                    Delete saved estimate\n                </a>\n            </div>\n            <hr />\n        </div>\n        <hr />\n    </div>\n</div>\n";
  });
if (typeof define === 'function' && define.amd) {
  define([], function() {
    return __templateData;
  });
} else if (typeof module === 'object' && module && module.exports) {
  module.exports = __templateData;
} else {
  __templateData;
}
});

;require.register("templates/save.form", function(exports, require, module) {
var __templateData = Handlebars.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, functionType="function", escapeExpression=this.escapeExpression;


  buffer += "<fieldset class=\"form-group\">\n    <div class=\"input-group\">\n        <input type=\"number\" placeholder=\"Profit Margin\" id=\"job-profit-margin\" name=\"profit_margin\" class=\"job field form-control\" value=\""
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.row)),stack1 == null || stack1 === false ? stack1 : stack1.margin)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\" />\n        <span class=\"input-group-addon\">%</span>\n    </div>\n    <input type=\"number\" placeholder=\"Subtotal\" id=\"job-subtotal\" name=\"subtotal\" class=\"job field form-control\" value=\"";
  if (helper = helpers.cost) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.cost); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\" data-original=\"";
  if (helper = helpers.cost) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.cost); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\" />\n</fieldset>\n\n<div class=\"row\">\n    <div class=\"col-xs-12 lead\">\n        <strong>\n            Job details\n        </strong>\n    </div>\n</div>\n\n<div id=\"job-accordion\" class=\"job items panel-group\"></div>\n\n<div class=\"row\">\n    <div class=\"col-xs-6\">\n        <button class=\"btn btn-primary job reset ccma-navigate form-control\" data-path=\"create\">Start Over</button>\n    </div>\n    <div class=\"col-xs-6\">\n        <button class=\"btn btn-success job save form-control\" data-path=\"home\">Save</button>\n    </div>\n</div>\n";
  return buffer;
  });
if (typeof define === 'function' && define.amd) {
  define([], function() {
    return __templateData;
  });
} else if (typeof module === 'object' && module && module.exports) {
  module.exports = __templateData;
} else {
  __templateData;
}
});

;require.register("views/base", function(exports, require, module) {
var BaseView, _ref,
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

module.exports = BaseView = (function(_super) {
  __extends(BaseView, _super);

  function BaseView() {
    _ref = BaseView.__super__.constructor.apply(this, arguments);
    return _ref;
  }

  BaseView.prototype.routeType = null;

  BaseView.prototype.self = null;

  BaseView.prototype.container = null;

  BaseView.prototype.templateFile = null;

  BaseView.prototype._child = null;

  BaseView.prototype.initialize = function() {
    if (this.self == null) {
      this.self = this.constructor;
    }
    if (this.container == null) {
      this.container = "." + this.routeType + "-items";
    }
    return null;
  };

  BaseView.prototype.render = function() {
    this.$el.html(this.template);
    console.log("Rendering " + this.routeType + " into " + this.container);
    $(this.container).append(this.$el);
    return this;
  };

  BaseView.prototype.setName = function() {
    this.$el.remove();
    delete this.el;
    this._ensureElement();
    return null;
  };

  return BaseView;

})(Backbone.View);
});

;require.register("views/browse", function(exports, require, module) {
var BaseView, BrowseView, ChoicesSingleton, _ref,
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

ChoicesSingleton = require("models/choices");

BaseView = require("views/base");

module.exports = BrowseView = (function(_super) {
  __extends(BrowseView, _super);

  function BrowseView() {
    _ref = BrowseView.__super__.constructor.apply(this, arguments);
    return _ref;
  }

  BrowseView.prototype.initialize = function(opts) {
    if (opts.routeType != null) {
      this.routeType = opts.routeType;
    }
    this.template = require('templates/browse');
    this.className = "" + this.routeType + " container";
    this.setName();
    return null;
  };

  BrowseView.prototype.render = function() {
    var self;
    this.$el.html(this.template({
      job_groups: ChoicesSingleton.get('job_groups')
    }));
    this.$('#browse-jobs').select2({
      minimumResultsForSearch: 6,
      matcher: function(term, optText, els) {
        var allText;
        allText = optText + els[0].parentNode.getAttribute('label') || '';
        return ('' + allText).toUpperCase().indexOf(('' + term).toUpperCase()) >= 0;
      }
    });
    self = this;
    this.$('#browse-jobs').click(function() {
      var value;
      value = 'read.' + self.$(this).val();
      return self.$('#browse-button').data('path', value);
    });
    return this;
  };

  return BrowseView;

})(BaseView);
});

;require.register("views/collection-form", function(exports, require, module) {
var CollectionFormView, CollectionView, ComponentFormView, _ref,
  __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

CollectionView = require("views/collection");

ComponentFormView = require("views/component-form");

module.exports = CollectionFormView = (function(_super) {
  __extends(CollectionFormView, _super);

  function CollectionFormView() {
    this.render = __bind(this.render, this);
    _ref = CollectionFormView.__super__.constructor.apply(this, arguments);
    return _ref;
  }

  CollectionFormView.prototype.tagName = "article";

  CollectionFormView.prototype.initialize = function(opts) {
    this.child = ComponentFormView;
    CollectionFormView.__super__.initialize.call(this, opts);
    if (opts.routeType != null) {
      this.routeType = opts.routeType;
    }
    this.id = "job-form-" + this.routeType;
    this.className = "container " + this.routeType + "-form-collection";
    this.multiple = (function() {
      switch (this.routeType) {
        case "create":
        case "job":
          return false;
        default:
          return true;
      }
    }).call(this);
    if (opts.step != null) {
      this.step = opts.step;
    }
    if (opts.title != null) {
      this.title = opts.title;
    }
    this.setName();
    this.template = require("templates/collection.form");
    return null;
  };

  CollectionFormView.prototype.render = function() {
    var self,
      _this = this;
    console.log("Rendering " + this.routeType + " collection");
    this._rendered = true;
    this.$el.empty();
    this.$el.html(this.template({
      routeType: this.routeType,
      step: this.step,
      title: this.title,
      multiple: this.multiple
    }));
    self = this;
    _(this._children).each(function(child) {
      var $component_help;
      _this.$(".items").append(child.render().$el);
      $component_help = _this.$('#component-help');
      if (child.model.help != null) {
        $component_help.text(child.model.help);
        $component_help.show();
      } else {
        $component_help.hide();
      }
      return _this.$("input[type=number]").keyup(function() {
        var new_val, template, val;
        val = self.$(this).val();
        if (val.lastIndexOf('.', 0) === 0) {
          template = '.0000000000';
          if (val === template.substring(0, val.length)) {
            return;
          }
          new_val = '0' + val;
          return self.$(this).val(new_val);
        }
      });
    });
    this.$('select').select2({
      allowClear: true,
      minimumResultsForSearch: 6
    });
    return this;
  };

  return CollectionFormView;

})(CollectionView);
});

;require.register("views/collection-list", function(exports, require, module) {
var CollectionListView, CollectionView, ComponentListView, _ref,
  __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

CollectionView = require("views/collection");

ComponentListView = require("views/component-list");

module.exports = CollectionListView = (function(_super) {
  __extends(CollectionListView, _super);

  function CollectionListView() {
    this.render = __bind(this.render, this);
    _ref = CollectionListView.__super__.constructor.apply(this, arguments);
    return _ref;
  }

  CollectionListView.prototype.initialize = function(opts) {
    this.child = ComponentListView;
    CollectionListView.__super__.initialize.call(this, opts);
    if (opts.routeType != null) {
      this.routeType = opts.routeType;
    }
    if (opts.modelType != null) {
      this.modelType = opts.modelType;
    }
    if (!this.id) {
      this.id = "job-list-" + this.modelType;
    }
    if (!this.className) {
      this.className = "" + this.modelType + "-list-collection";
    }
    if (opts.title != null) {
      this.title = opts.title;
    }
    if (opts.step != null) {
      this.step = opts.step;
    }
    this.setName();
    this.template = require("templates/collection.list");
    return null;
  };

  CollectionListView.prototype.render = function() {
    var _this = this;
    console.log("Rendering " + this.modelType + " list collection");
    this._rendered = true;
    this.$el.empty();
    this.$el.html(this.template({
      modelType: this.modelType,
      routeType: this.routeType,
      title: this.title,
      cost: this.collection.calculate != null ? this.collection.calculate().toFixed(2) : void 0
    }));
    _(this._children).each(function(child) {
      return _this.$(".items").append(child.render().$el);
    });
    return this;
  };

  return CollectionListView;

})(CollectionView);
});

;require.register("views/collection", function(exports, require, module) {
var BaseView, CollectionView, ComponentView, _ref,
  __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

BaseView = require("views/base");

ComponentView = require("views/component");

module.exports = CollectionView = (function(_super) {
  __extends(CollectionView, _super);

  function CollectionView() {
    this.add = __bind(this.add, this);
    _ref = CollectionView.__super__.constructor.apply(this, arguments);
    return _ref;
  }

  CollectionView.prototype.initialize = function(opts) {
    if (opts.routeType != null) {
      this.routeType = opts.routeType;
    }
    this.modelType = opts.modelType != null ? opts.modelType : "collection";
    if (this.className == null) {
      this.className = "" + this.modelType + "-collection";
    }
    if (opts.child != null) {
      this.child = opts.child;
    }
    if (this.child == null) {
      this.child = ComponentView;
    }
    this._children = [];
    this._rendered = false;
    this.setName();
    this.collection.each(this.add);
    _(this).bindAll('add', 'remove');
    this.listenTo(this.collection, 'add', this.add);
    this.listenTo(this.collection, 'remove', this.remove);
    return null;
  };

  CollectionView.prototype.render = function() {
    var _this = this;
    console.log("Rendering " + this.modelType + " collection");
    this._rendered = true;
    this.$el.empty();
    _(this._children).each(function(child) {
      return _this.$(".items").append(child.render().$el);
    });
    return this;
  };

  CollectionView.prototype.add = function(model) {
    var child;
    child = new this.child({
      model: model,
      modelType: this.modelType,
      routeType: this.routeType
    });
    this._children.push(child);
    if (this._rendered) {
      this.$(".items").append(child.render().$el);
    }
    return null;
  };

  CollectionView.prototype.remove = function(model) {
    var orphan;
    orphan = _(this._children).select(function(child) {
      return child.model === model;
    });
    orphan = orphan.unshift();
    orphan.stopListening();
    this._children = _(this._children).without(orphan);
    if (this._rendered) {
      orphan.$el.remove();
    }
    return null;
  };

  return CollectionView;

})(BaseView);
});

;require.register("views/component-form", function(exports, require, module) {
var ChoicesSingleton, ComponentFormView, ComponentView, _ref,
  __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

ComponentView = require("views/component");

ChoicesSingleton = require("models/choices");

module.exports = ComponentFormView = (function(_super) {
  __extends(ComponentFormView, _super);

  function ComponentFormView() {
    this.refresh = __bind(this.refresh, this);
    _ref = ComponentFormView.__super__.constructor.apply(this, arguments);
    return _ref;
  }

  ComponentFormView.prototype.events = {
    "change .field": "refresh"
  };

  ComponentFormView.prototype.initialize = function(opts) {
    ComponentFormView.__super__.initialize.call(this, opts);
    this.template = require("templates/component.form");
    this.className = "" + this.routeType + " " + this.routeType + "-form " + this.routeType + "-form-item";
    this.setName();
    _.bindAll(this, "refresh");
    return null;
  };

  ComponentFormView.prototype.refresh = function(event) {
    var choices_options, field, name, option_found, select2_selected_option, selected_option, target;
    target = $(event.currentTarget);
    name = target.attr('name');
    this.model.set(name, target.val());
    field = this.model.getField(name);
    if ((field != null) && (field.optionsType != null) && field.fieldType === 'hidden') {
      selected_option = target.select2('data');
      choices_options = ChoicesSingleton.get(field.optionsType);
      option_found = _.some(choices_options, function(item) {
        return item.id === selected_option.id && item.text === selected_option.text;
      });
      if (!option_found) {
        select2_selected_option = target.select2('data');
        choices_options.push({
          id: select2_selected_option.id,
          text: select2_selected_option.text
        });
      }
    }
    console.log("View changed", target.attr('name'), target.val());
    $("." + this.routeType + ".cost").text(this.model.collection.calculate().toFixed(2));
    return null;
  };

  return ComponentFormView;

})(ComponentView);
});

;require.register("views/component-list", function(exports, require, module) {
var ComponentListView, ComponentView, _ref,
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

ComponentView = require("views/component");

module.exports = ComponentListView = (function(_super) {
  __extends(ComponentListView, _super);

  function ComponentListView() {
    _ref = ComponentListView.__super__.constructor.apply(this, arguments);
    return _ref;
  }

  ComponentListView.prototype.tagName = "li";

  ComponentListView.prototype.initialize = function(opts) {
    this.showAll = true;
    ComponentListView.__super__.initialize.call(this, opts);
    this.template = require("templates/component.list");
    this.className = "" + this.routeType + " " + this.routeType + "-list " + this.routeType + "-list-item list-group-item";
    this.setName();
    return null;
  };

  ComponentListView.prototype.render = function() {
    this.$el.html(this.template({
      overview_items: this.model.overview()
    }));
    return this;
  };

  return ComponentListView;

})(ComponentView);
});

;require.register("views/component", function(exports, require, module) {
var BaseView, ComponentView, _ref,
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

BaseView = require("views/base");

module.exports = ComponentView = (function(_super) {
  __extends(ComponentView, _super);

  function ComponentView() {
    _ref = ComponentView.__super__.constructor.apply(this, arguments);
    return _ref;
  }

  ComponentView.prototype.initialize = function(opts) {
    if (opts.routeType != null) {
      this.routeType = opts.routeType;
    }
    if (this.showAll == null) {
      this.showAll = false;
    }
    this.templateFile = "templates/component.list";
    this.className = this.routeType;
    this.setName();
    return null;
  };

  ComponentView.prototype.addSelectOption = function(field) {
    return this.$('input[name=' + field.name + ']').select2({
      width: 'resolve',
      data: field.options,
      createSearchChoice: function(term) {
        var option_found;
        option_found = _.some(field.options, function(item) {
          return item.text === term;
        });
        if (option_found) {
          return null;
        } else {
          return {
            id: String(field.options.length + 1),
            text: term
          };
        }
      }
    });
  };

  ComponentView.prototype.render = function() {
    var field, _i, _len, _ref1;
    this.$el.html(this.template({
      row: this.model.toJSON(),
      routeType: this.routeType,
      cid: this.model.cid,
      cost: this.model.calculate != null ? this.model.calculate().toFixed(2) : void 0,
      fields: this.model.getFields(this.showAll)
    }));
    _ref1 = this.model.fields;
    for (_i = 0, _len = _ref1.length; _i < _len; _i++) {
      field = _ref1[_i];
      if (field.fieldType === 'hidden' && field.show && (field.options != null)) {
        this.addSelectOption(field);
      }
    }
    return this;
  };

  return ComponentView;

})(BaseView);
});

;require.register("views/delete-browse", function(exports, require, module) {
var BaseView, ChoicesSingleton, DeleteBrowseView, _ref,
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

ChoicesSingleton = require("models/choices");

BaseView = require("views/base");

module.exports = DeleteBrowseView = (function(_super) {
  __extends(DeleteBrowseView, _super);

  function DeleteBrowseView() {
    _ref = DeleteBrowseView.__super__.constructor.apply(this, arguments);
    return _ref;
  }

  DeleteBrowseView.prototype.initialize = function(opts) {
    if (opts.routeType != null) {
      this.routeType = opts.routeType;
    }
    this.template = require('templates/delete-browse');
    this.className = "" + this.routeType + " container";
    this.setName();
    return null;
  };

  DeleteBrowseView.prototype.render = function() {
    var self;
    this.$el.html(this.template({
      job_groups: ChoicesSingleton.get('job_groups')
    }));
    this.$('#delete-job').select2({
      minimumResultsForSearch: 6,
      matcher: function(term, optText, els) {
        var allText;
        allText = optText + els[0].parentNode.getAttribute('label') || '';
        return ('' + allText).toUpperCase().indexOf(('' + term).toUpperCase()) >= 0;
      }
    });
    this.$('#delete-group').select2({
      minimumResultsForSearch: 6
    });
    self = this;
    this.$('#delete-job').click(function() {
      var data, value;
      data = self.$(this).select2('data');
      value = 'delete-job.' + data.id;
      return self.$('#delete-job-button').data('path', value).data('name', data.text);
    });
    this.$('#delete-group').click(function() {
      var data, value;
      data = self.$(this).select2('data');
      value = 'delete-group.' + data.id;
      return self.$('#delete-group-button').data('path', value).data('name', data.text);
    });
    this.$('#delete-job-button').click(function(e) {
      var name, path;
      e.preventDefault();
      name = self.$(this).data('name');
      if (!name) {
        bootbox.alert("No job estimate selected");
        return;
      }
      path = self.$(this).data('path');
      return bootbox.confirm("Delete the job estimate '" + name + "'?", function(result) {
        if (result) {
          return Backbone.history.navigate(path, true);
        }
      });
    });
    this.$('#delete-group-button').click(function(e) {
      var name, path;
      e.preventDefault();
      name = self.$(this).data('name');
      if (!name) {
        bootbox.alert("No group selected");
        return;
      }
      path = self.$(this).data('path');
      return bootbox.confirm("Delete the group '" + name + "' and all of it's jobs?", function(result) {
        if (result) {
          return Backbone.history.navigate(path, true);
        }
      });
    });
    return this;
  };

  return DeleteBrowseView;

})(BaseView);
});

;require.register("views/job-element-form", function(exports, require, module) {
var ChoicesSingleton, CollectionListView, ComponentView, JobElementFormView, _ref,
  __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

ComponentView = require("views/component");

CollectionListView = require("views/collection-list");

ChoicesSingleton = require("models/choices");

module.exports = JobElementFormView = (function(_super) {
  __extends(JobElementFormView, _super);

  function JobElementFormView() {
    this.refresh = __bind(this.refresh, this);
    this.render = __bind(this.render, this);
    _ref = JobElementFormView.__super__.constructor.apply(this, arguments);
    return _ref;
  }

  JobElementFormView.prototype.tagName = "article";

  JobElementFormView.prototype.events = {
    "change .field": "refresh"
  };

  JobElementFormView.prototype.initialize = function(opts) {
    var collection, data, _i, _len, _ref1;
    JobElementFormView.__super__.initialize.call(this, opts);
    if (opts.routeType != null) {
      this.routeType = opts.routeType;
    }
    this.id = "job-form-" + this.routeType;
    this.className = "container " + this.routeType + " " + this.routeType + "-form";
    if (opts.step != null) {
      this.step = opts.step;
    }
    if (opts.title != null) {
      this.title = opts.title;
    }
    this.templateFile = "templates/" + this.routeType + ".form";
    this.template = require(this.templateFile);
    if (this.routeType === 'save') {
      this._children = [];
      _ref1 = ChoicesSingleton.get('job_routes');
      for (_i = 0, _len = _ref1.length; _i < _len; _i++) {
        collection = _ref1[_i];
        data = this.model.attributes[collection] != null ? this.model.attributes[collection] : false;
        this._children.push(new CollectionListView({
          className: "job-list-collection",
          collection: data,
          title: collection,
          modelType: collection,
          routeType: this.routeType
        }));
      }
    }
    this.setName();
    _.bindAll(this, "refresh");
    return null;
  };

  JobElementFormView.prototype.addSelectOption = function(field) {
    return this.$('input[name=' + field.name + ']').select2({
      width: 'resolve',
      data: field.options,
      createSearchChoice: function(term) {
        var option_found;
        option_found = _.some(field.options, function(item) {
          return item.text === term;
        });
        if (option_found) {
          return null;
        } else {
          return {
            id: String(field.options.length + 1),
            text: term
          };
        }
      }
    });
  };

  JobElementFormView.prototype.render = function() {
    var field, self, _i, _len, _ref1,
      _this = this;
    console.log("Rendering " + this.routeType + " element");
    this.$el.empty();
    this.$el.html(this.template({
      row: this.model.toJSON(),
      cid: this.model.cid,
      routeType: this.routeType,
      step: this.step,
      title: this.title,
      cost: this.model.cost.toFixed(2),
      fields: this.model.getFields(this.showAll)
    }));
    _ref1 = this.model.fields;
    for (_i = 0, _len = _ref1.length; _i < _len; _i++) {
      field = _ref1[_i];
      if (field.fieldType === 'hidden' && field.show && (field.options != null)) {
        this.addSelectOption(field);
      }
    }
    self = this;
    this.$('#job-profit-margin').keyup(function() {
      var $subtotal, profit_margin, subtotal_original, subtotal_value;
      profit_margin = self.$(this).val();
      $subtotal = self.$('#job-subtotal');
      subtotal_original = $subtotal.data('original');
      if (isNaN(parseFloat(profit_margin)) || !isFinite(profit_margin)) {
        $subtotal.val(subtotal_original);
        return;
      }
      profit_margin /= 100;
      subtotal_original = parseFloat(subtotal_original);
      subtotal_value = subtotal_original + (subtotal_original * profit_margin);
      return $subtotal.val(subtotal_value.toFixed(2));
    });
    _(this._children).each(function(child) {
      return _this.$(".job.items").append(child.render().$el);
    });
    return this;
  };

  JobElementFormView.prototype.refresh = function(event) {
    var choices_options, field, name, option_found, select2_selected_option, selected_option, target;
    target = $(event.currentTarget);
    name = target.attr('name');
    this.model.set(name, target.val());
    field = this.model.getField(name);
    if ((field != null) && (field.optionsType != null) && field.fieldType === 'hidden') {
      selected_option = target.select2('data');
      choices_options = ChoicesSingleton.get(field.optionsType);
      option_found = _.some(choices_options, function(item) {
        return item.id === selected_option.id && item.text === selected_option.text;
      });
      if (!option_found) {
        select2_selected_option = target.select2('data');
        choices_options.push({
          id: select2_selected_option.id,
          text: select2_selected_option.text
        });
      }
    }
    console.log("View changed", target.attr('name'), target.val());
    return null;
  };

  return JobElementFormView;

})(ComponentView);
});

;require.register("views/job-list", function(exports, require, module) {
var ComponentView, JobListView, _ref,
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

ComponentView = require("views/component");

module.exports = JobListView = (function(_super) {
  __extends(JobListView, _super);

  function JobListView() {
    _ref = JobListView.__super__.constructor.apply(this, arguments);
    return _ref;
  }

  JobListView.prototype.tagName = "li";

  JobListView.prototype.initialize = function(opts) {
    JobListView.__super__.initialize.call(this, opts);
    this.template = require("templates/job.list");
    this.className = "" + this.routeType + " " + this.routeType + "-list " + this.routeType + "-list-item list-group-item";
    this.setName();
    return null;
  };

  return JobListView;

})(ComponentView);
});

;require.register("views/job", function(exports, require, module) {
var BaseView, ChoicesSingleton, CollectionListView, JobView, _ref,
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

BaseView = require("views/base");

CollectionListView = require("views/collection-list");

ChoicesSingleton = require("models/choices");

module.exports = JobView = (function(_super) {
  __extends(JobView, _super);

  function JobView() {
    _ref = JobView.__super__.constructor.apply(this, arguments);
    return _ref;
  }

  JobView.prototype.initialize = function(opts) {
    var collection, data, _i, _len, _ref1;
    this._children = [];
    if (opts.routeType != null) {
      this.routeType = opts.routeType;
    }
    this.id = this.model.cid;
    this.className = "" + this.routeType + "-overview";
    this.setName();
    this.template = require("templates/job");
    _ref1 = ChoicesSingleton.get('job_routes');
    for (_i = 0, _len = _ref1.length; _i < _len; _i++) {
      collection = _ref1[_i];
      data = this.model.attributes[collection] != null ? this.model.attributes[collection] : false;
      this._children.push(new CollectionListView({
        className: "job-list-collection",
        collection: data,
        title: collection,
        modelType: collection,
        routeType: this.routeType
      }));
    }
    return null;
  };

  JobView.prototype.render = function() {
    var _this = this;
    console.log("Rendering job overview");
    this.model.calculate();
    this.$el.html(this.template({
      row: this.model.getFields(),
      cost: this.model.cost.toFixed(2)
    }));
    _(this._children).each(function(child) {
      return _this.$(".job.items").append(child.render().$el);
    });
    return this;
  };

  return JobView;

})(BaseView);
});

;require.register("views/page", function(exports, require, module) {
var PageView, _ref,
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

module.exports = PageView = (function(_super) {
  __extends(PageView, _super);

  function PageView() {
    _ref = PageView.__super__.constructor.apply(this, arguments);
    return _ref;
  }

  PageView.prototype.tagName = "section";

  PageView.prototype.className = "page";

  PageView.prototype.title = "Cole";

  PageView.prototype.text = null;

  PageView.prototype.subView = null;

  PageView.prototype.initialize = function(opts) {
    this.section = require("templates/page");
    this.header = require("templates/header");
    if (opts.title != null) {
      this.title = opts.title;
    }
    if (opts.text != null) {
      this.text = opts.text;
    }
    if (opts.subView != null) {
      this.subView = opts.subView;
    }
    return true;
  };

  PageView.prototype.render = function() {
    var header, _ref1, _ref2;
    this.$el.empty();
    if (this.title != null) {
      header = this.header({
        title: this.title,
        step: (_ref1 = (_ref2 = this.subView) != null ? _ref2.step : void 0) != null ? _ref1 : null
      });
      console.log("Rendering page header");
      this.$el.append(header);
    }
    if (this.text != null) {
      this.$el.append(this.section({
        text: this.text
      }));
      console.log("Rendering page view");
    }
    if (this.subView != null) {
      console.log("Appending form view");
      this.$el.append(this.subView.render().$el);
    }
    return this;
  };

  return PageView;

})(Backbone.View);
});

;
//# sourceMappingURL=app.js.map